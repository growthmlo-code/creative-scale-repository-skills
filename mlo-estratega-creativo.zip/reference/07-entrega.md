# Cómo entregas · nunca solo texto

Un muro de texto con números no se lee y no se decide sobre él. **Siempre que haya datos, hay visual.**

---

## Regla base

| Lo que piden | Cómo lo entregas |
|---|---|
| Un KPI suelto ("¿hit rate de X?") | Titular en una frase + el número grande + su benchmark al lado. Widget pequeño. |
| Panel de marca / "¿cómo va X?" | **Widget dashboard**: los 6 KPIs en tarjetas con semáforo + curva de supervivencia + el veredicto |
| Forecast / "¿cuántos creativos necesita?" | **Widget con las 4 gráficas** + la tabla contrato/modelo/brecha |
| Comparativa entre marcas | **Widget tabla** con semáforos por columna |
| Algo para enseñar al cliente | **Artifact** con el template de deck MLO |
| Una pregunta conceptual | Texto. No fuerces un gráfico donde no hay datos. |

Usa `mcp__visualize__show_widget` para lo inline (llama antes a `read_me` en silencio, sin narrarlo). Usa `Artifact` solo cuando sea para el cliente o el usuario pida algo compartible.

---

## Marca MLO

```
Fondo    #090909      Verde    #4AFF53
Texto    #FFFFFF      Alarma   #FF4A4A      Aviso  #FFC24A
```

Titulares en serif, datos en sans. Números grandes y con aire — el KPI es el protagonista, no la etiqueta.

Respeta el tema claro/oscuro del visor cuando el widget lo permita, pero el acento verde `#4AFF53` se mantiene siempre.

---

## Dashboard de marca — la estructura por defecto

1. **Titular** — una frase con el número que importa. *"B3TTER necesita 62 creativos este mes; el pod da 30."*
2. **Fila de tarjetas** — los 6 KPIs, cada uno con su valor, su benchmark y un semáforo 🔴🟡🟢
3. **La cadena del forecast** — los 5 pasos en horizontal, con el número de cada paso. Que se vea el razonamiento, no solo el resultado.
4. **Tabla contrato / modelo / brecha** — con la brecha destacada
5. **Gráficas** — las que apliquen (ver abajo)
6. **Diagnóstico** — 1 frase + 1-3 acciones
7. **Avisos de calidad del dato** — pequeño, al pie

---

## Las 4 gráficas (especificación visual)

**1 · Curva de forecast** — línea. X: lanzamientos/mes · Y: gasto sostenible. Punto marcado donde está la marca hoy.

**2 · Estado actual vs deseado** ⭐ — dos líneas. Gris apagada = hit rate actual. Verde `#4AFF53` = hit rate objetivo. **Sombrea el área entre ambas**: eso es lo que se gana arreglando el motor. Es la gráfica del cliente.

**3 · Curva de supervivencia** — línea descendente. X: días · Y: % de winners vivos. Línea horizontal punteada en el 50% y etiqueta con el half-life en el cruce. Una línea por cohorte si hay datos.

**4 · Requerimiento mensual** — barras agrupadas. Requerido vs contratado, 6-12 meses. La brecha en rojo.

---

## Reglas de lectura

- **Semáforo siempre.** Un número sin su benchmark al lado no dice nada. `8,2% 🟡` comunica; `8,2%` no.
- **El titular primero.** Si alguien solo lee la primera línea, tiene que salir sabiendo qué hacer.
- **Muestra el razonamiento del forecast**, no solo el resultado. La cadena de 5 pasos visible es lo que hace que el equipo confíe en el número y aprenda a calcularlo.
- **Nada de decorar.** Sin gradientes, sin iconos de relleno, sin gráficos 3D. Si un elemento no ayuda a decidir, fuera.
- **Móvil.** Tarjetas que se apilen, tablas anchas con scroll propio.

---

## Cuando falten datos

No dejes el hueco en blanco ni inventes. Marca la tarjeta en gris con `—` y una nota corta: *"falta umbral del KPI Panel"*. Un dashboard honesto con dos huecos vale más que uno completo con dos números inventados.

---

## Documento de Volumen Creativo (deck HTML — v2, sep 2026)

La skill produce un **deck HTML de una sola página, compartible** cuando se pide el documento de volumen creativo de una marca. Es el entregable que se pasa al equipo, se publica como noticia y se manda por el canal de Slack de la marca.

**Foco del documento:** responder "qué volumen creativo necesita esta cuenta y qué tenemos que producir" — no si el pod cubre o no. Nada de referencias a pods, contrato ni paquete de servicio.

**Ejemplo de referencia:** `reference/ejemplo-volumen-creativo.html` (Moncho Moreno ES, sep 2026). Seguir este HTML como plantilla de diseño y estructura.

### Los 9 bloques (en este orden)

**1 · Hero + tesis** — Nombre de marca, pills de contexto (tier, umbral, moneda, ads/periodo), y un bloque de tesis con borde lateral que resume en una frase lo que pasa y el dato clave. La tesis cambia según el diagnóstico: verde si cubre, ámbar si hay déficit manejable, rojo si es emergencia. No hay un héroe fijo — el héroe es la situación de la marca.

**2 · Los 6 KPIs** — Grid 3×2 con tarjetas. Cada tarjeta tiene: dot semáforo (verde/ámbar/rojo/gris), nombre del KPI, valor grande, nota con benchmark, fuente. Los KPIs sin dato van en gris con `—` y la razón. Los 6: hit rate anuncio, hit rate brief, churn A (vida media), churn B (% drop), gasto/winner + test tax.

**3 · Forecast (cadena de 5 pasos)** — Los 5 pasos en horizontal con flechas: winners necesarios → sobreviven → nuevos → creativos → + buffer. Debajo, una nota con: inversión objetivo (dato real del cliente, NO el gasto de agosto como proxy), €/winner, y si hay déficit o superávit vs lo producido.

**4 · Inversión sostenible vs objetivo** — Barra de progreso con la inversión sostenible (winners × €/winner) contra el objetivo. Porcentaje de cobertura y el gap en euros. Si la cobertura es <70%, ámbar; <50%, rojo.

**5 · Ritmo semanal + receta de producción** — Tres cards de ritmo: (a) creativos/semana objetivo, (b) ritmo actual, (c) incremento necesario. **Debajo, el desglose clave: conceptos nuevos × variaciones por concepto + iteraciones de winners.** Esto es lo que el equipo necesita para planificar la semana. La receta se calcula así:
- Iteraciones de winners = top 5 winners actuales × 2-3 variaciones/semana de cada uno
- Conceptos nuevos = (creativos/semana − iteraciones) ÷ variaciones/concepto
- Variaciones/concepto recomendadas: ~3 de media (2 para tests nuevos, 4-5 para ángulos probados)
- Incluir un bloque explicativo que diga: "producir 3 variaciones de un winner es más rápido y más probable que ganar que crear 3 conceptos desde cero"

**6 · Formatos: qué producir** — Tabla con: formato (Static/Video/Carousel/UGC), winners agosto, % del total, ROAS medio, €/winner, target/mes, target/semana. Se llena decodificando la naming convention de los winners. Si un formato tiene 0 winners, se marca como "Testear".

**7 · Ángulos y productos: dónde apostar** — Dos visualizaciones:
- **Tipo de contenido**: barras horizontales con el nº de winners por ángulo (UGC-style, Founder Led, Oferta/DR, Before/After, USP, FAQ, Problem/Solution, etc.)
- **Línea de producto**: cards con nombre, nº de winners, nota, y un tag (Motor principal / Segundo pilar / Subrepresentado / Oportunidad fácil / Escalar más / Diversificado)
- Cierra con un párrafo "Dónde apostar" que dice qué funciona, qué está subrepresentado, y qué testear

**8 · Diagnóstico + plan de acción** — Diagnóstico: bloque con 2-3 párrafos en bold + explicación. Acciones: lista priorizada P1-P5 con acción concreta, números, y highlight en verde de lo importante.

**9 · Calidad del dato** — Bloque con borde dashed. Tres categorías: Medido (qué viene de Meta API), Objetivo (inversión objetivo — quién lo dio), Supuesto (churn B benchmark, buffer), Gaps (qué falta para mejorar la precisión).

### Datos necesarios para generar el documento

Para cada marca se necesita:

| Dato | Fuente | Obligatorio |
|---|---|---|
| Ads con nombre, gasto, ROAS (mes anterior) | Meta API `ads_get_ad_entities` level `ad` | Sí |
| Umbral ROAS de la marca | KPI Panel (Notion) | Sí |
| Objetivo de inversión del mes siguiente | Input del cliente o MB | Sí |
| ROAS objetivo del mes siguiente | Input del cliente o MB | Sí |
| Churn B real | Cruzar winners mes anterior vs actual | Ideal (benchmark 40% si no hay) |

### Proceso paso a paso

1. **Query Meta API** — `ads_get_ad_entities`, account de la marca, level `ad`, `date_preset: last_month`, fields: `name, spend, purchase_roas, impressions`. Filtro: spend > suelo (50€/equiv).
2. **Identificar winners** — gasto ≥ suelo AND ROAS ≥ umbral del KPI Panel.
3. **Decodificar naming convention** — Extraer de los nombres de los winners: formato (Static/Video/Carousel), línea de producto, ángulo/framework, funnel stage. El naming varía por marca; ver `reference/02-marcas.md`.
4. **Calcular los 6 KPIs** — HR anuncio, HR brief (si hay dato), churn B (si hay dato, si no 40%), gasto/winner, test tax.
5. **Calcular forecast con objetivo real** — No usar gasto de agosto como proxy. Usar el objetivo de inversión que da el cliente.
6. **Calcular ritmo semanal** — Total creativos ÷ 4 semanas. Desglosar en conceptos × variaciones + iteraciones.
7. **Agrupar formato/ángulo/producto** — Tablas y bars a partir del naming decodificado.
8. **Escribir diagnóstico y acciones** — Basado en el tier de la marca y los gaps detectados.
9. **Publicar como Artifact** — Una página por marca, compartible.

### Paleta y estilo

- **Fondo**: `#090909` (dark) / `#f6f5f3` (light) — siempre theme-aware con tokens CSS
- **Cards**: `rgba(255,255,255,0.04)` dark / `rgba(0,0,0,0.025)` light
- **Verde accent**: `#4AFF53` dark / `#1a8f2a` light
- **Alarma**: `#FF4A4A` dark / `#c03030` light
- **Aviso**: `#FFC24A` dark / `#9a6e00` light
- **Texto**: `#EDEDED` dark / `#18181b` light
- **Fuente**: Manrope (Google Fonts), pesos 400-800
- **Max-width**: 860px centrado
- **Responsive**: grid 3col → 2col en mobile, chain horizontal → vertical
- **NO usar Chart.js ni CDN externos** — todo inline CSS, sin dependencias
- Fuente en CADA número; lo proxy/ausente en gris con `—` y marcado
