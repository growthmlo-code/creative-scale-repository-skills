# Informe Semanal de Estrategia Creativa — Guía de Generación de la Plantilla

Esta es la versión en español (España) de la plantilla, sin vincular a ninguna marca, plataforma publicitaria o herramienta de analítica concreta: la estructura, el orden de las secciones y el sistema de diseño son el activo reutilizable. Usa esta guía para explicar la plantilla a una marca potencial, o para dársela a quien deba rellenarla para un cliente real.

## Qué es esto

Un único archivo HTML autocontenido (`weekly-creative-report-template-ES.html`), con estilo de presentación a pantalla completa y fondo oscuro (una `<section>` por diapositiva, pensado para verse como una presentación, no para desplazarse como un informe). Se lee de un vistazo en una reunión de dirección: cifras grandes, callouts breves, sin muros de texto.

La plantilla ya incluye todas las secciones, todas las clases CSS y todos los layouts. Rellenarla consiste en sustituir los marcadores entre corchetes como `[Nombre de Marca]`, `$[XX.XXX]`, `[X,XX]x` por cifras reales. No hace falta tocar la estructura HTML/CSS para una semana normal.

## Paleta de color

El acento principal es verde: `--accent: #478358`, con `#8FBF9E` (tono claro) y `#2E5940` (tono oscuro) como extremos de los degradados, y `#00200C` como color de texto oscuro sobre fondos claros (pills, avatar). Los colores semánticos se mantienen: verde `--good` para positivo, rojo `--bad` para negativo, ámbar `--warn` para advertencia. No mezclar el verde de acento con el verde semántico de "good": son variables CSS distintas a propósito.

## Las 15 secciones, en orden

1. **Portada** — nombre de marca, título del informe, rango de fechas, destinatarios, base de atribución.
2. **KPIs Generales** — cuadrícula de 8 tarjetas: Inversión, Ingresos, ROAS, ROAS NC (ROAS de cliente nuevo), Pedidos, Ticket Medio, CPA, Anuncios Activos, cada una con su variación vs. el periodo anterior.
3. **% de Clientes Nuevos** *(sección nueva)* — el % de pedidos (o ingresos) de clientes nuevos, con dos comparativas: vs. semana anterior y vs. el mismo periodo del mes anterior. Es la señal principal de crecimiento neto de la cuenta, por eso va casi al principio, justo después del resumen general.
4. **Cuentas Publicitarias** — solo si la marca gestiona más de una cuenta publicitaria (p. ej. una cuenta principal más una cuenta secundaria de advertorial). Eliminar esta diapositiva por completo si solo hay una cuenta.
5. **Inversión y Tasa de Aciertos por Producto** — cuadrícula de 4 tarjetas, una por producto/categoría principal más un cajón "Sin Categorizar" para la inversión que no se puede atribuir a un producto concreto.
6. **Rendimiento por Responsable** — tabla de quién es responsable de cada creatividad (puede ser un estratega, una agencia, un equipo interno), con inversión, anuncios probados, aciertos, tasa de aciertos y variación semana a semana.
7. **Mejores Páginas: Embudo CTR → CVR** — tabla de páginas de destino ordenadas por inversión, mostrando el embudo completo de clic a compra (CTR y luego CVR) más el ROAS NC, para ver de un vistazo qué página recibe clics pero no convierte.
8. **Dónde Vive la Inversión por Fase de Conocimiento** — cuadrícula de 4 tarjetas por fase de conocimiento (Consciente del Problema / Consciente de la Solución / Consciente del Producto / No Consciente: términos estándar del embudo de mensaje, no específicos de ninguna marca).
9. **Rendimiento por Fase del Embudo** — un gráfico de 3 barras tipo "torre" para TOF / MOF / BOF, ordenado por ROAS NC, con una línea de umbral discontinua marcando la barrera de rentabilidad.
10. **Los 3 Mejores Anuncios** — los tres anuncios de mayor inversión, cada uno marcado como Acierto o Fallo según el umbral que use la marca.
11. **Mejores y Peores Anuncios de la Semana** — dos subsecciones: anuncios de poca inversión con una señal positiva temprana ("En Ascenso"), y anuncios de inversión real con muy mal rendimiento ("Inversión Desperdiciada"). No ordenado por inversión.
12. **Mejor y Peor Audiencia** — tabla de audiencias/segmentos objetivo ordenados por ROAS NC.
13. **Análisis de Lanzamientos** — una ventana móvil (normalmente 14 días) que clasifica cada anuncio recién lanzado como Prometedor, Fracaso, o Aún Pronto Para Valorar.
14. **Mejores Creadores** *(sección nueva)* — tabla de creadores (UGC, influencers, talent) ordenada por inversión en sus anuncios, con su ROAS NC al lado. El objetivo es cruzar ambos ejes: quién mueve más presupuesto no siempre es quien lo hace de forma más rentable, y esta sección tiene que dejarlo claro. Va casi al final, justo antes de la lectura final.
15. **Lectura del Estratega Creativo** — la diapositiva de cierre: una cita destacada con el hallazgo más importante del periodo, un callout opcional de benchmark del sector, y una lista de acciones numerada. Aquí también vive la lista de "qué hacer ahora"; no existe una diapositiva de acciones aparte.

## Reglas de diseño (no te apartes de ellas)

- **No toques nunca el bloque `<style>`.** Los colores, el espaciado, el CSS de tarjetas/tablas/pills y las posiciones de los `.glow-orb` son la identidad visual que se está mostrando. Cambia solo el contenido dentro de las secciones.
- **Una `<section>` por diapositiva.** Cada una ya tiene una posición única de `.glow-orb`, no repitas la misma posición dos veces seguidas.
- **Sin rayas largas (—) en ningún texto generado.** Usa un punto, dos puntos, coma o paréntesis en su lugar. Aplica a callouts, etiquetas de tarjetas y texto de la cita.
- **Los callouts llevan el análisis, no el dato.** Las tablas y tarjetas muestran cifras; las cajas `.callout` explican qué significan esas cifras y qué hacer al respecto. Empieza por la cifra, no por la introducción ("Mejor eficiencia: $1.750 a 2,87x" es mejor que "El anuncio con mejor rendimiento esta semana fue uno que gastó $1.750...").
- **El símbolo de moneda es un valor de marca, no un dato fijo de la plantilla.** Los marcadores usan `$` por defecto, pero confirma la moneda real de la marca en el paso de configuración y sustitúyelo de forma consistente en todo el documento (`$` vs. `€`, posición del símbolo, separador decimal `,` habitual en español de España) antes de entregar el informe.
- **Cualquier callout que nombre 3 o más ejemplos debe ir en viñetas** (`<ul class="tight">` dentro del callout), no en un párrafo corrido.
- **Lógica de color:** `.up` / verde para lo bueno, `.down` / rojo para lo malo, `.flat` / gris para lo neutro. Nunca marques dos veces el mismo dato con color (si la cifra de una tarjeta ya está en verde, su subtexto se queda en gris neutro).
- **Los pills se ganan, no son decorativos.** Otorga un `pill-solid` ("Mayor Inversión," "Dominante," "Mejor Rendimiento") o una insignia `pill-hit`/`pill-bad` solo a la tarjeta/fila que de verdad tiene la mejor o peor cifra de su grupo, recalculado cada vez, nunca copiado de una semana anterior.
- **El cajón "Sin Categorizar" o "Sin Etiquetar" nunca lleva pill ni estilo de highlight**, aunque sus cifras parezcan buenas. Es un cajón de calidad de datos, no un competidor más.

## Cómo rellenar esto para una marca real

1. **Reúne lo básico de la marca:** nombre, logo (o usa la marca genérica de la plantilla), ventana de reporte, plataforma(s) publicitaria(s), modelo y ventana de atribución (p. ej. "basado en Pixel, first-click, 1 día"), y para quién es el informe.
2. **Define el umbral de "acierto"** para esa cuenta: normalmente una inversión mínima y un ROAS o ROAS NC mínimo. Este umbral se usa en todo el mazo (Producto, Responsable, Página de Destino, Mejores Anuncios): defínelo una vez y aplícalo de forma consistente, que no varíe de una diapositiva a otra.
3. **Extrae las métricas** de la fuente de analítica que use la marca (Triple Whale, GA4, el reporting nativo de la plataforma publicitaria, un data warehouse, etc.) para cada sección: KPIs generales, % de clientes nuevos con sus dos comparativas, inversión/ROAS por producto, por responsable, por página de destino, por fase de conocimiento, por fase del embudo, por audiencia, por creador, además de las listas de mejores/peores anuncios y la clasificación de lanzamientos nuevos.
4. **Sustituye cada marcador entre corchetes** por el valor real. Elimina cualquier diapositiva que no aplique (lo más habitual: la de Cuentas Publicitarias, si solo hay una cuenta).
5. **Escribe los callouts al final**, una vez estén todas las cifras. Cada callout debe decir algo que un estratega diría en voz alta en la reunión, no una descripción de cómo se calculó la cifra. Las notas de metodología y los matices de los datos van en una línea de subtítulo pequeña o en un `.callout.warn`, nunca como el punto analítico principal.
6. **Recalcula cada pill e insignia desde cero** contra las cifras que acabas de rellenar; no arrastres un pill de "Mayor Inversión" o "Mejor" de un ejemplo de plantilla.
7. **Revisa que el informe se lea de arriba a abajo como una sola historia**: el Resumen marca la cifra titular, cada diapositiva intermedia añade una capa de detalle, y la Lectura del Estratega Creativo final lo conecta todo con 4-6 acciones concretas que hagan referencia a cifras ya mostradas antes en el informe.

## Qué NO hacer

- No inventes datos. Cada marcador entre corchetes debe sustituirse por una cifra real y con fuente, no por una estimación que suene plausible.
- No añadas nuevos tipos de diapositiva o componentes CSS sin una necesidad real. Si el reporting de una marca de verdad no necesita una diapositiva de "Cuentas Publicitarias," elimínala, no la dejes a medio rellenar.
- No conviertas los callouts en una lista de definiciones o un escrito de metodología. Ese contenido, si hace falta que exista, va en un documento interno aparte, no delante de la sala.
