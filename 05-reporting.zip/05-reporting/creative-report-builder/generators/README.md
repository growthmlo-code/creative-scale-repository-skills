# Generadores del reporte creativo (13 secciones canónicas)

Producen la estructura FIJA de 13 secciones y renumeran los footers solos.

- `canon.py` — generador ES. `canon_en.py` — generador EN. Estructura idéntica; solo cambian títulos/idioma.
- `growth.py` — helper de la slide 03 (Crecimiento / % Clientes Nuevos) **con NCPA**. `growth.block(lang, cur_pct, new_o, tot_o, prev_wk_pct, prev_mo_pct, callout, ncpa=, prev_ncpa=, cur=, source=)`.
- `prod.py` — helper de la slide 05 (Producto) para marcas de UN SOLO producto: `prod.single(name, spend, roas, orders, ads, note, lang)`. PRODUCTO = producto real; el ÁNGULO va SIEMPRE en la slide 06 aparte.
- `BRAND_DATA.md` — datos de clientes nuevos + NCPA ya sacados por marca (semana 3–9 ago 2026).
- `examples/` — 3 scripts de build reales (MUTO/QiHealth/V-UP) como plantilla de uso.

## Las 13 secciones (orden fijo)
01 Portada · 02 KPIs · 03 Crecimiento (%NC + NCPA) · 04 Embudo · 05 **Producto (real)** · 06 **Ángulo (separado)** · 07 Owner · 08 Conocimiento · 09 Fase del Embudo · 10 Mejores Anuncios · 11 Mejores y Peores · 12 Creadores · 13 Lectura.

## Uso
```python
import importlib.util
spec=importlib.util.spec_from_file_location("canon","canon.py"); canon=importlib.util.module_from_spec(spec)
canon.PREP="Equipo MLO · MARCA"; canon.WINDOW='<span>3–9 ago, 2026</span>'
spec.loader.exec_module(canon)
import growth, prod
crecimiento=growth.block("es", 67.7, 1594, 2353, 65.3, 70.2, "<div class='callout'>…</div>", ncpa=9.2, prev_ncpa=7.7, cur="€")
# producto (real) + angulo (separado) + resto de slides …
inner=dict(kpis=…, crecimiento=crecimiento, embudo=…, producto=…, angulo=…, owner=…, conocimiento=…, fase_embudo=…, top3=…, mejores=…, creadores=…)
canon.build("MARCA","Título","Subtítulo", canon.metarow("Base","Moneda"), inner, lectura, "/ruta/out.html")
```
