# Datos por marca — semana 3–9 ago 2026 (Shopify store-level + NCPA)
NCPA = gasto Meta del reporte / clientes nuevos (Shopify). Formato: cur% (new/tot) · WoW pts · MoM pts · NCPA cur (prev).

- ZZEN (EUR):   67,7% (1594/2353) · +2,4 · −2,5 · NCPA €9,2 (€7,7)   [spend €14.610 / prev €12.617; ojo tiene Google]
- MUTO (GBP):   59,0% (59/100)   · −6,8 · +26,9 · NCPA £102,5 (£92,5) [spend £6.050 / prev £4.440]  ← corregido (atribuido daba 89%)
- Bala (MXN):   73,7% (497/674)  · +1,4 · −12,5 · NCPA $417 ($347)   [spend $207.159 / prev $139.296]
- Alma (EUR):   64,3% (27/42)    · +5,2 · +27,5 · NCPA €37,9 (€41,8) [spend €1.024 / prev €543]
- 8hours (EUR): 25,9% (116/448)  · −0,8 · +14,6 · NCPA €66,7 (€55,2) [spend €7.738 / prev €6.404]  ← 74% recompra
- QiHealth (MXN): 82,4% (103/125)· +0,6 · −0,3 · NCPA $433 ($316)   [spend $44.601 / prev $36.942]
- V-UP (COP):   71,6% (63/88)    · +2,2 · −6,4 · NCPA $115.436 ($104.613) [spend MLO $7.272.449 / prev $6.172.176]
- Pendientes Shopify: Fajitex, Henric, COEUS.
