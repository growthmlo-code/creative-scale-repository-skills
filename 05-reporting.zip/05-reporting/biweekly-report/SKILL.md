---
name: biweekly-report
description: "Generate a biweekly (bisemanal) performance report for any e-commerce brand using Shopify Analytics + Atria (Meta Ads). Outputs a self-rendering HTML report and a Notion summary page. ALWAYS use this skill when the user asks for a biweekly report, reporte bisemanal, performance report, brand report, or any periodic report involving Shopify and/or Meta Ads data. Also trigger when the user mentions 'reporte', 'bisemanal', 'Atria', or asks to analyze Shopify + Meta Ads performance for a specific period."
---

# Biweekly Brand Performance Report

Generate a professional, self-rendering HTML report for any e-commerce brand by pulling data from Shopify Analytics and Atria (Meta Ads), then populating a branded HTML template and creating a Notion summary page.

## Prerequisites

- **Chrome access** (Claude in Chrome) for navigating Shopify and Atria dashboards
- **Notion MCP** for creating the summary page
- **HTML template** bundled in `references/template.html`

## Brand Configuration

Before starting, gather these parameters from the user (or from a brand config if available):

| Parameter | Example (iEnergy) | Description |
|---|---|---|
| `brand_name` | iEnergy | Display name for the report |
| `shopify_url` | `https://admin.shopify.com/store/ienergy-store/analytics` | Shopify Analytics URL |
| `atria_url` | `https://app.tryatria.com/workspace/analytics/facebook/988a6fce31114d858f6618f87a7cfd01` | Atria workspace URL |
| `notion_parent_id` | `27d6c997-7eb7-8060-b824-ee33fcf3c4e4` | Notion parent page ID (Portal de Cliente) |
| `currency` | COP | Currency code for formatting |
| `products` | iEnergy BOX, Greens, Ultimate Protein | Main products to track |

If the user doesn't provide these, ask for them before proceeding.

---

## Workflow (Step by Step)

### Step 1: Determine Report Period

Calculate the reporting period:
- **Current period**: last 14 completed days (or as specified by the user)
- **Previous period**: the 14 days before that (for comparison)
- Format dates as `DD Mon YYYY` (e.g., "11 Mar 2026")

### Step 2: Extract Shopify Data

1. Navigate to the brand's Shopify Analytics URL
2. Set the date range to the current period using the date picker:
   - Click the date range selector at the top
   - Select "Custom" date range
   - Use the calendar UI to pick start and end dates (click directly on the day numbers)
   - Click "Apply"
3. Take a screenshot and extract these KPIs:
   - **Gross Sales** (and vs previous period)
   - **Net Sales**
   - **Orders** (count)
   - **AOV** (Average Order Value)
   - **Sessions**
   - **Conversion Rate** (CVR)
   - **Returning Customer Rate**
   - **Top Products by Sales** (from the product breakdown section)
4. Scroll down to capture the conversion funnel:
   - Sessions → Added to Cart → Reached Checkout → Completed Purchase
   - Get both volume and rate for each step

**Tips for Shopify extraction:**
- The `get_page_text` tool sometimes returns the currency dropdown instead of metrics. Use screenshots as your primary data source.
- If the date picker is tricky, click directly on the calendar day numbers rather than typing dates.
- Take multiple screenshots scrolling down to capture all sections.

### Step 3: Extract Atria / Meta Ads Data

1. Navigate to the brand's Atria workspace URL
2. Set the date range to the current period
3. Extract these KPIs from the overview:
   - **Ad Spend** (Inversión)
   - **Purchase Value / Revenue**
   - **ROAS**
   - **CPA** (Cost per Acquisition)
   - **CPM**
   - **Impressions**
   - **Reach**
   - **Link Clicks / CTR**
   - **Frequency**
4. Navigate to the Creatives section and extract the **Top 8 performing ads** by ROAS (with spend > 30K threshold):
   - Ad name, format (Video/Image), ROAS, Spend, Angle/Category
5. Extract **Creative Diversity Score** (Atria Score out of 100)
6. Extract engagement metrics: Hook Rate (Thumbstop), Hold Rate, Click-to-ATC, Click-to-Purchase
7. Extract the funnel data: Impressions → Reach → Clicks → ATC → Checkouts → Purchases
8. Note the **Atria Tags** if visible: Personas, Desires, USPs with weights

**Tips for Atria extraction:**
- The zoom screenshot function may return blank images. Use regular screenshots instead.
- Scroll through the creatives section to capture all top performers.
- Compare current vs previous period values for % change calculations.

### Step 4: Populate the HTML Template

1. Read the HTML template from `references/template.html`
2. The template is a self-rendering HTML file with a JavaScript `R` data object (around line 155-316) that drives the entire report
3. **Replace the entire `R` object** with new data. The `R` object structure is:

```javascript
const R = {
  client:       "BRAND_NAME",
  period:       "DD Mon – DD Mon YYYY",
  prev_period:  "DD Mon – DD Mon YYYY",
  date_gen:     "DD/MM/YYYY",
  channels:     "Meta Ads · Shopify",

  status: {
    revenue:   { s:"g"|"a"|"r"|"n", label:"Revenue: ..." },
    cpa:       { s:"g"|"a"|"r"|"n", label:"CPA: ..." },
    retencion: { s:"g"|"a"|"r"|"n", label:"Retención: ..." },
    checkout:  { s:"g"|"a"|"r"|"n", label:"Checkout: ..." },
  },

  snapshot: {
    status: "g"|"a"|"r",
    text: "HTML summary paragraph",
    wins: ["win 1", "win 2", ...],
    alerts: ["alert 1", "alert 2", ...],
  },

  // KPIs: [name, current, previous, variation, status]
  // status: "g" (green/good), "a" (amber/attention), "r" (red/bad), "n" (neutral)
  kpi_paid: [ ... ],   // Meta Ads KPIs
  kpi_store: [ ... ],  // Shopify KPIs

  revenue_chart: {
    days: ["D1","D2",...,"D10"],
    current: [/* relative 0-100 values */],
    prev: [/* relative 0-100 values */],
  },

  insights: [
    { obs: "observation", why: "root cause", act: "action" },
    ...
  ],

  funnel: [
    ["Step", "current_vol", "prev_vol", "% change", "rate"],
    ...
  ],

  creatives: [
    ["Ad name", "$spend", "$CPA", purchases_number, "winner"|"scale"|"test"|"pause"|"learn"],
    ...
  ],

  atria_personas: [["Name", weight_0_100], ...],
  atria_desires:  [["Name", weight_0_100], ...],
  atria_usps:     [["Name", weight_0_100], ...],

  next_creatives: ["<strong>Title</strong> — explanation", ...],

  funnel_store: [
    ["Step", "current", "previous", "status", "observation"],
    ...
  ],

  products: [
    ["Product", "$current", "$previous", "+XX%", "status"],
    ...
  ],

  mix_producto: [["Name", pct, "#hexcolor"], ...],
  mix_canal:    [["Name", pct, "#hexcolor"], ...],

  funnel_detect: ["detection 1", "detection 2", ...],
  funnel_reco:   ["recommendation 1", ...],

  actions: [
    ["Action text", "Agencia"|"Cliente", "Area", "S1"|"S2", "fire"|"bolt"|"norm"],
    ...
  ],

  pending: ["Pending item 1", ...],
};
```

4. Status codes: `"g"` = green (good), `"a"` = amber (needs attention), `"r"` = red (critical), `"n"` = neutral
5. Creative tags: `"winner"` (top performer), `"scale"` (ready to scale), `"test"` (testing), `"pause"` (stop), `"learn"` (gathering data)
6. Action priority: `"fire"` = urgent, `"bolt"` = important, `"norm"` = normal

### Step 5: Validate the HTML

Since you can't preview the HTML in Chrome (file:// and localhost URLs don't work in the sandbox), validate the R object using Node.js:

```bash
node -e "
  const fs = require('fs');
  const html = fs.readFileSync('OUTPUT_FILE', 'utf8');
  const match = html.match(/const R = (\{[\s\S]*?\});/);
  if (!match) { console.log('ERROR: R object not found'); process.exit(1); }
  try { eval('(' + match[1] + ')'); console.log('R object is valid JS'); }
  catch(e) { console.log('ERROR:', e.message); process.exit(1); }
"
```

### Step 6: Create Notion Summary Page

1. Create a new page under the brand's Notion portal using `notion-create-pages`
2. Title: `Biweekly Report – DD/MM - DD/MM`
3. Icon: `📊`
4. Populate with a structured Markdown version of the report containing:
   - General Overview with all key metrics
   - Period-over-Period comparison tables (Meta Ads + Shopify)
   - Funnel Performance tables
   - Top Creatives table
   - Creative Engagement metrics
   - Product Performance table
   - Conclusion and Next Steps

### Step 7: Save & Present

1. Save the HTML file as `{brand}_Reporte_{startDate}-{endDate}_{year}.html` in the outputs folder
2. Present the file to the user using `present_files`
3. Inform the user they need to manually drag-and-drop the HTML file into the Notion page (Notion doesn't support automated file uploads via API)

---

## Analysis Guidelines

When filling in the qualitative sections (insights, snapshot, actions), apply these principles:

- **Snapshot**: Lead with the headline metric (purchases or revenue), mention ROAS, and call out the #1 risk
- **Status assignment**: Compare metrics to industry benchmarks and previous period. Use "g" if improving and healthy, "a" if declining or below benchmark, "r" if critical
- **Insights**: Each should have a clear observation → root cause → specific action. Be data-driven, not generic
- **Actions**: Prioritize by impact. S1 = this week, S2 = next week. "fire" = revenue-critical, "bolt" = important optimization, "norm" = nice-to-have
- **Creative tagging**: "winner" = highest spend + profitable ROAS, "scale" = good ROAS but low spend, "test" = early data, "learn" = not enough data yet, "pause" = poor performance
- **Revenue chart**: Normalize daily values to 0-100 scale (100 = highest day). Use approximate values if exact daily data isn't available

## Currency Formatting

- Use the brand's local currency (usually COP for Colombian brands)
- Format with periods as thousands separator: `$9.600.000`
- Use `M` suffix for millions in tables: `COP 9.6M`
- ROAS always uses `x` suffix: `1.78x`
