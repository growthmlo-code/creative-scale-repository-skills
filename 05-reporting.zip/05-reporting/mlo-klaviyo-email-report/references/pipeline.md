# ⚙️ Pipeline — Klaviyo Email Report

## 0) Confirmar cuenta + metric de conversión
- `get_account_details` (fields: `contact_information.organization_name`, `industry`, `preferred_currency`) → confirma la marca conectada.
- `get_metrics` (fields: `name`) → coge el id de **"Placed Order"** (Shopify). Ej. English Path = `Rcbp5d`. Es el `conversion_metric_id` de todos los reports.

## 1) Campañas (rendimiento)
`get_campaign_report`:
- `conversion_metric_id`: <Placed Order id>
- `statistics`: recipients, delivered, delivery_rate, open_rate, opens_unique, click_rate, clicks_unique, click_to_open_rate, conversions, conversion_rate, conversion_uniques, unsubscribe_rate, unsubscribes, bounce_rate, spam_complaint_rate
- `value_statistics`: conversion_value, average_order_value, revenue_per_recipient
- `group_by`: ["campaign_id","campaign_message_id","campaign_message_name"]
- `filters`: `equals(send_channel,"email")`
- `timeframe`: {start,end} ISO (ventana del periodo)
→ Devuelve stats + nombre/send_time por campaña. **CTR del report = `click_rate` (unique clicks / delivered).**

## 2) Asuntos (para Detalle + Best Subjects)
`get_campaigns`:
- `filter`: `and(equals(messages.channel,'email'),greater-or-equal(scheduled_at,<inicio-margen>))`
- `include`: ["campaign-messages"], `fields_campaign_message`: ["definition.content.subject","definition.content.preview_text","send_times"], `fields_campaign`: ["name","send_time","status"]
→ Join por `campaign_id` con el report para tener el **asunto real** de cada campaña. (El "name" suele ser una fecha, NO el asunto.)

## 3) Flows (automatizaciones)
`get_flow_report` (mismos statistics/value_statistics), `group_by`:["flow_id","flow_name"], `filters`: `equals(send_channel,"email")`, mismo timeframe.
→ Resultado suele ser grande (se guarda a archivo). Parsear con python: **agregar por flow_name** (sumar conversion_value, conversions, recipients, opens_unique, clicks_unique) porque hay varias flow-messages por flow.

## 4) Cálculos clave
- `email_rev = camp_rev + flow_rev`; `flow% = flow_rev/email_rev` (casi siempre 70–85%).
- Campañas ponderadas: OR = Σopens_unique/Σdelivered · CTR = Σclicks_unique/Σdelivered · CTOR = Σclicks/Σopens · Unsub = Σunsub/Σdelivered.
- AOV = email_rev / pedidos totales.
- Best subjects: ordenar campañas por open_rate y por click_rate/CTOR.

## 5) Build (skin M.L.O)
- Leer `creative-report-builder/generators/mlo_head.html` + `mlo_logo.html`, inyectar en el HTML.
- Clases del skin: `section`, `.glow-orb`, `.logo`, `h1 .hl`, `.subtitle`, `.meta-row`, `.eyebrow`, `h2`, `.kpi-grid`/`.kpi-card`(+`.hero`)/`.kpi-value`(+`.gradient-num`)/`.kpi-delta`(+`.up`/`.down`/`.flat`), `.table-panel`>`table`, `.pill-hit`/`.pill-bad`/`.pill-solid`/`.pill-soft`, `.callout`(+`.good`/`.bad`/`.warn`)+`ul.tight`, `.product-grid`/`.product-card`(+`.highlight`)/`.bar-track`/`.bar-fill`/`.stat-*`, `.ad-card`(+`.hit`/`.miss`)/`.ad-status`, `.num-list`, `.quote-mark`/`.quote-text`(+`.hl2`)/`.quote-attr`/`.avatar-circle`, `.footer-tag`.
- Formato € europeo (miles `.`, decimales `,`). Verificar `#4ADE80` + `class="logo-img"` en el output.
- Render (preview) + screenshot portada y una slide de datos antes de entregar.

## Ejemplo validado
Script del piloto English Path (ago-2026): `scratchpad/build_email_report.py` de la sesión. Deck: `Downloads/english-path-email-report-2026-08.html`.
