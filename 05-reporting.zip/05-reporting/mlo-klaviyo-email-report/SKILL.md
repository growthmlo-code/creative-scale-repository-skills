---
name: mlo-klaviyo-email-report
description: >
  Genera el M.L.O Email Marketing Report — un deck cliente-facing (una slide por sección, skin
  M.L.O oscuro byte-idéntico al creative report) con el rendimiento de EMAIL de una marca desde
  KLAVIYO: KPIs globales vs benchmark, Campañas vs Flows, detalle por campaña, BEST PERFORMING
  SUBJECTS, flows/automatizaciones, lo que funcionó/no, lista & deliverability, aprendizajes,
  plan y Lectura del Email Strategist. Cadencia bisemanal. USA SIEMPRE esta skill (ES/EN) cuando
  pidan: "reporte de email de [marca]", "email report", "reporte de Klaviyo", "reporte de
  newsletter", "reporte de email marketing", "klaviyo report", "deck de email de [marca]",
  "cómo rinde el email de [marca]", "best subjects de [marca]". Es el gemelo de email del
  creative-report-builder. Reutilizable para cualquier cliente con email marketing en Klaviyo.
---

# M.L.O · Klaviyo Email Marketing Report

Deck cliente-facing del rendimiento de **email (Klaviyo)** de una marca, con el **mismo branding M.L.O** que el creative report (dark #070a07, verde #4ADE80, Playfair/DM Sans, glow-orbs, una slide por sección). Nació del piloto de **English Path** (ago-2026) a partir del estilo del creative-report + la referencia del report de email de Nurse is Love.

## Estructura (12 slides — FIJA)
1. **Portada** — Reporte de Email Marketing · [Marca] · [periodo] · Fuente Klaviyo.
2. **KPIs Globales** — Revenue email (hero) · Revenue Campañas · Revenue Flows · AOV · Open · Click · CTOR · Unsub, con **benchmark de sector** (OR 20–30% · CTR 2–3% · Unsub <0,3%).
3. **Campañas vs Flows** — split del revenue (dónde vive el dinero). Casi siempre los flows dominan.
4. **Detalle por Campaña** — Fecha · Asunto · Open · Click · Revenue · Pedidos.
5. **Best Performing Subjects** — top asuntos por apertura y por clic + qué estilo gana (reto/auto-diagnóstico vs estacional vs descriptivo).
6. **Flows / Automatizaciones** — Welcome, Checkout/Cart/Browse Abandonment, Onboarding, Thank You, Sunset, Winback, Replenishment (Revenue · Pedidos · Open · Click).
7. **Lo que mejor funcionó** — 3 tarjetas hit (mejor revenue · mejor clic · mejor apertura).
8. **Lo que no funcionó** — 2 tarjetas miss (peor revenue/clic).
9. **Lista & Deliverability** — OR salud · Unsub · Bounce · Spam (+ crecimiento de lista si se conecta).
10. **Lo que aprendemos** — bullets accionables.
11. **Qué cambiamos** — num-list del plan (A/B de asunto, subir clic, escalar campañas, sunset…).
12. **Lectura del Email Strategist** — quote de cierre + attr M.L.O.

Nunca elimines una slide: si falta el dato (p.ej. crecimiento de lista), se mantiene con nota honesta (`.callout.warn`/`.small`), igual que en el creative report.

## Cómo se construye
- **Skin M.L.O empaquetado y portable:** `creative-report-builder/generators/mlo_head.html` (style+fuentes) y `mlo_logo.html` (logo base64). Se inyectan tal cual → branding byte-idéntico. Verifica que el HTML final contiene `#4ADE80` y `class="logo-img"`.
- **Datos:** Klaviyo MCP (ver `references/pipeline.md` para la secuencia exacta de tools).
- **Salida:** un HTML autocontenido `<brand-slug>-email-report-<periodo>.html`. Render + verificación visual (portada + una slide de datos) antes de entregar.

## Reglas
- **Cadencia bisemanal** (cada 14 días), como el report de NIL.
- **Cuenta Klaviyo:** el MCP se conecta a UNA cuenta — confirma con `get_account_details` de qué marca es antes de titular el deck. Para otra marca hay que conectar su Klaviyo.
- **CTR suele ser el gap** (0,5–1% vs 2–3% sector) → es casi siempre el foco del plan.
- **Best Subjects** es sección obligatoria (petición de Marcel).

---
**Ficheros:** `references/pipeline.md` (secuencia Klaviyo + parseo + script de build). **Relacionado:** creative-report-builder (gemelo de paid/creativo, mismo skin), mlo-email-marketing-lab.
