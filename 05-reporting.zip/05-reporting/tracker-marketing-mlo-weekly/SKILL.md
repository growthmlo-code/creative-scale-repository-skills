---
name: tracker-marketing-mlo-weekly
description: Actualización automática del Paid Ads Tracker de Marketing M.L.O cada lunes a las 8am (Europe/Madrid). Extrae Meta Ads agencia + iClosed → pega en mes corriente → Slack DM resumen + chase de outcomes pendientes.
---

Ejecuta el skill mlo-marketing-tracker-weekly para la semana cerrada anterior (lunes 7d atrás a domingo ayer). Pasos:

1. Calcula el rango de la semana cerrada.
2. Extrae Meta Ads de la cuenta agencia M.L.O Growth - Marcel (408860354532385) con time_increment=1.
3. Extrae calls de iClosed (app.iclosed.io) en ese rango via Chrome — Past tab + Date Range picker.
4. Aplica las 8 reglas duras del SKILL.md: excluir Marcel-como-invitee, Q=T, J=K=H, I=0 por defecto, no inventar Ventas/Cash si iClosed no tiene outcome.
5. Pega en la pestaña del mes corriente del tracker (https://docs.google.com/spreadsheets/d/1X-1ujv5H1gJbF8exC9WqMqTn--Gwkxcvg6rPG5Ouv5g/edit) respetando fórmulas.
6. Envía Slack DM a Marcel (U090VQYDH7Z) con resumen ejecutivo: inversión, calls, asistencias, ventas, CAC, ROI Cash, tendencia vs semana anterior, top 2 acciones recomendadas, link al tracker.
7. Si hay calls sin outcome marcado en iClosed → envía Slack DM separado con chase + lista de calls a marcar.

Si la pestaña del mes no existe en el sheet → avisa a Marcel y NO crees automáticamente.