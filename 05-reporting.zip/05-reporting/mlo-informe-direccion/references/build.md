# 🛠️ Build — export a PDF + verificación

## 1) Base
Duplica `plantilla-informe-ejemplo.html` (informe real ya validado con toda la CSS MLO inline) y rellena el contenido. NO toques la paleta ni las fuentes. Guarda el HTML final en `~/Downloads/MLO_Informe_<Tema>_<Fecha>.html`.

## 2) CSS de impresión (ya incluida en la plantilla — no quitar)
```css
body{ ... -webkit-print-color-adjust:exact; print-color-adjust:exact }
@page{margin:14mm}
@media print{
  body::before{display:none}                 /* quita el grid de fondo en print */
  .sec{break-inside:avoid;padding-top:20px}
  .sol,.stat,.callout,.tbl,.steps{break-inside:avoid}
  .cover{min-height:auto;padding:20px 0 40px} /* la portada se compacta en PDF */
  .wrap{padding:0 24px 24px}
}
```

## 3) Exportar a PDF (Chrome headless)
```bash
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
cd ~/Downloads && "$CHROME" --headless --disable-gpu --no-pdf-header-footer \
  --print-to-pdf="MLO_Informe_<Tema>_<Fecha>.pdf" \
  "file:///Users/mlo/Downloads/MLO_Informe_<Tema>_<Fecha>.html"
```
- `--no-pdf-header-footer` es OBLIGATORIO: sin él, Chrome mete la fecha y la ruta `file://` en cada página (feo).
- `@page{margin:14mm}` da el marco blanco; sin márgenes Marcel lo rechaza ("no hay márgenes").

## 4) Verificar lo que renderiza (double-check, memoria de Marcel)
```bash
cd ~/Downloads && qlmanage -t -s 1000 -o . "MLO_Informe_<Tema>_<Fecha>.pdf"   # genera <pdf>.png de la 1ª página
```
Lee ese PNG y comprueba: portada correcta, sin header/footer de Chrome, márgenes OK, nombres propios bien escritos. Borra el `.png` temporal al terminar. Para ver una sección concreta en pantalla:
```bash
"$CHROME" --headless --disable-gpu --window-size=920,2600 --hide-scrollbars --screenshot="_chk.png" "file:///…html"
```
(en pantalla la portada ocupa todo el viewport; el compactado real solo se ve en el PDF).

## 5) Entrega
`SendUserFile` con el **PDF + HTML** (display render). El HTML queda editable por si Marcel retoca.

## Notas de estilo aprendidas
- El navegador interno (claude-in-chrome) NO abre `file://` → verifica con Chrome headless + qlmanage, no con el navegador.
- Nombres propios: confírmalos (ej. "Andrey", no "Andrei").
- Encuadre honesto: marca las soluciones como **"⏳ Por ejecutar"** vs hechas; no vendas como cerrado lo que está en debate.
