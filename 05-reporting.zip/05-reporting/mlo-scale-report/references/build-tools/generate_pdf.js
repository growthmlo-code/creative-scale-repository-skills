const fs = require("fs");
const puppeteer = require("puppeteer-core");

const LOGO = "data:image/png;base64," + fs.readFileSync("assets/mlo_logo.png").toString("base64");
const LOGO_COVER = "data:image/png;base64," + fs.readFileSync("assets/mlo_logo_cover.png").toString("base64");

// M.L.O Growth brand
const C = { bg:"#070C08", card:"#0F1810", card2:"#16241A", line:"#244430",
  gold:"#4AFA53", green:"#4AFA53", greenD:"#1AA838", red:"#F2616B", white:"#FFFFFF", mute:"#93A79A", dim:"#5F7268" };

// ---------- chart helpers (inline SVG) ----------
function vBars(vals, labs, color) {
  const W=920, H=300, padB=44, padT=34, padL=8, padR=8;
  const max = Math.max(...vals)*1.12, plotH=H-padB-padT, plotW=W-padL-padR;
  const slot=plotW/vals.length, bw=slot*0.46;
  let s=`<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">`;
  vals.forEach((v,i)=>{ const h=v/max*plotH, x=padL+slot*i+(slot-bw)/2, y=padT+plotH-h;
    s+=`<rect x="${x}" y="${y}" width="${bw}" height="${h}" rx="4" fill="${color}"/>`;
    s+=`<text x="${x+bw/2}" y="${y-9}" fill="${C.white}" font-size="17" font-family="Helvetica" text-anchor="middle">${v}</text>`;
    s+=`<text x="${x+bw/2}" y="${H-16}" fill="${C.mute}" font-size="17" font-family="Helvetica" text-anchor="middle">${labs[i]}</text>`; });
  return s+`</svg>`;
}
function hBars(vals, labs, color) {
  const W=820, H=320, padL=92, padR=70, padT=10, padB=10;
  const max=Math.max(...vals)*1.1, plotW=W-padL-padR, plotH=H-padT-padB;
  const slot=plotH/vals.length, bh=slot*0.55;
  let s=`<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">`;
  vals.forEach((v,i)=>{ const w=v/max*plotW, y=padT+slot*i+(slot-bh)/2;
    s+=`<rect x="${padL}" y="${y}" width="${w}" height="${bh}" rx="4" fill="${color}"/>`;
    s+=`<text x="${padL-12}" y="${y+bh/2+6}" fill="${C.mute}" font-size="18" font-family="Helvetica" text-anchor="end">${labs[i]}</text>`;
    s+=`<text x="${padL+w+10}" y="${y+bh/2+6}" fill="${C.white}" font-size="18" font-family="Helvetica">${v}%</text>`; });
  return s+`</svg>`;
}
function lineChart(vals, labs, color, ymax) {
  const W=920, H=300, padL=50, padR=20, padT=24, padB=40;
  const plotW=W-padL-padR, plotH=H-padT-padB;
  const xs=i=>padL+plotW*i/(vals.length-1), ys=v=>padT+plotH-(v/ymax)*plotH;
  let s=`<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">`;
  for(let g=0; g<=4; g++){ const yy=padT+plotH*g/4, val=(ymax*(4-g)/4);
    s+=`<line x1="${padL}" y1="${yy}" x2="${W-padR}" y2="${yy}" stroke="${C.line}" stroke-width="1"/>`;
    s+=`<text x="${padL-10}" y="${yy+5}" fill="${C.mute}" font-size="14" font-family="Helvetica" text-anchor="end">${Math.round(val)}</text>`; }
  let pts=vals.map((v,i)=>`${xs(i)},${ys(v)}`).join(" ");
  s+=`<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="3.5"/>`;
  vals.forEach((v,i)=>{ s+=`<circle cx="${xs(i)}" cy="${ys(v)}" r="5" fill="${color}"/>`;
    s+=`<text x="${xs(i)}" y="${ys(v)-13}" fill="${C.white}" font-size="15" font-family="Helvetica" text-anchor="middle">${v}</text>`;
    s+=`<text x="${xs(i)}" y="${H-14}" fill="${C.mute}" font-size="15" font-family="Helvetica" text-anchor="middle">${labs[i]}</text>`; });
  return s+`</svg>`;
}

const wrap = (n, kicker, title, body) => `
<section class="slide">
  <div class="kicker"><span class="sq"></span>${kicker.toUpperCase()}</div>
  <h1 class="title">${title}</h1>
  ${body}
  <img class="flogo" src="${LOGO}"/>
  <div class="footer">Moncho Moreno · Reporte de Inversión · Ene–Jun 2026</div>
  <div class="pageno">${String(n).padStart(2,"0")}</div>
</section>`;

// ---------- slides ----------
const slides = [];

// S1 portada
slides.push(`
<section class="slide cover">
  <div class="goldbar"></div>
  <img class="cv-logo" src="${LOGO_COVER}"/>
  <div class="cv-brand">Moncho Moreno</div>
  <div class="cv-sub">Reporte Financiero &amp; de <i>Inversión</i></div>
  <div class="cv-rule"></div>
  <div class="cv-meta1">Enero – Junio 2026&nbsp;&nbsp;·&nbsp;&nbsp;España (EUR)</div>
  <div class="cv-meta2">Meta Ads · Shopify · Triple Whale · Atria</div>
  <div class="cv-foot">Datos reconciliados a 22 jun 2026</div>
</section>`);

// S2 veredicto
slides.push(wrap(2,"01 · Veredicto","Estamos infrainvirtiendo en paid — de forma severa",`
  <div class="row3">
    ${[["4,4%","Inversión / Facturación","sano DTC: 15–30%",C.gold],
       ["21,7x","MER (blended)","ROAS Meta 7–16x vs breakeven 1,6",C.green],
       ["9,7x","LTGP : CAC",'zona ">3 = infrainversión"',C.green]]
      .map(s=>`<div class="card stat"><div class="big" style="color:${s[3]}">${s[0]}</div><div class="lbl-b">${s[1]}</div><div class="lbl-m">${s[2]}</div></div>`).join("")}
  </div>
  <ul class="bullets">
    <li><b style="color:${C.gold}">Cuánto invertir:</b> el sistema (unit economics + creativo + recurrencia) aguanta 2–3× más presupuesto.</li>
    <li><b style="color:${C.gold}">Cuello de botella:</b> es el PRESUPUESTO, no el creativo (win rate 28%, excepcional).</li>
    <li><b style="color:${C.green}">Dinero sobre la mesa:</b> ≈ €90–130K / año de contribución*.</li>
  </ul>
  <div class="note">El matiz honesto: parte del ROAS alto es harvesting de demanda branded del fundador → escalar midiendo incrementalidad (geo-holdout), no a ciegas.</div>`));

// S3 situacion
slides.push(wrap(3,"02 · Situación del negocio","Negocio fuerte y estacional — con el paid minúsculo",`
  <div class="split">
    <div class="col-stats">
      ${[["€729,6K","Facturación gross 6M",C.white],["11.697","Pedidos",C.white],
         ["€33,6K","Inversión en paid",C.gold],["63%","Revenue de cliente recurrente",C.green]]
        .map(s=>`<div class="kpi"><div class="kpi-v" style="color:${s[2]}">${s[0]}</div><div class="kpi-l">${s[1]}</div></div>`).join("")}
    </div>
    <div class="card chart-card">
      <div class="chart-title">Facturación mensual (€K gross)</div>
      <div class="chart">${vBars([239.8,64.2,94.6,72.6,197.7,60.6],["Ene","Feb","Mar","Abr","May","Jun*"],C.gold)}</div>
    </div>
  </div>
  <div class="note">Picos: Enero (rebajas) y Mayo (Cumple Moncho). Feb–Abr y Jun = valle. El negocio vive de eventos + orgánico del fundador; el paid es solo el 4,4% de la facturación.</div>`));

// S4 unit economics
slides.push(wrap(4,"03 · Unit economics","Rentable desde la primera compra — con margen enorme",`
  <div class="split">
    <div style="flex:1.15">
      <table class="tbl">
        <tr><th>Métrica</th><th>60%*</th><th class="hl">62,5%*</th><th>65%*</th></tr>
        <tr><td>Breakeven ROAS</td><td>1,67</td><td class="hl">1,60</td><td>1,54</td></tr>
        <tr><td>MCPA · 1ª compra</td><td>€25,4</td><td class="hl">€26,7</td><td>€28,0</td></tr>
        <tr><td>MC ROAS</td><td>6,1</td><td class="hl">6,4</td><td>6,6</td></tr>
      </table>
      <div class="tnote">* margen bruto supuesto (sin COGS reales)</div>
    </div>
    <div class="grid2">
      ${[["€50,7","New AOV (neto)",C.white],["€7,70","nCAC (cliente nuevo)",C.gold],
         ["8,13x","aMER (NC-ROAS)",C.green],["€2,87","CPA blended",C.white]]
        .map(s=>`<div class="card mini"><div class="mini-v" style="color:${s[2]}">${s[0]}</div><div class="mini-l">${s[1]}</div></div>`).join("")}
    </div>
  </div>
  <div class="note big-note"><b style="color:${C.white}">La 1ª compra de un cliente nuevo deja ~€26,7* de contribución y cuesta €7,70 adquirirlo</b> <span style="color:${C.green};font-weight:bold">→ margen positivo desde el primer pedido, antes de contar recurrencia.</span></div>`));

// S5 LTV
slides.push(wrap(5,"04 · LTV & LTGP : CAC","El cliente casi dobla su primer pedido en 12 meses",`
  <div class="split">
    <div class="card decisive">
      <div class="dec-lbl">LTGP : CAC</div>
      <div class="dec-big">9,7x</div>
      <div class="dec-zone">zona ">3 = infrainversión"</div>
      <div class="dec-sub">LTV rev €120* · LTGP €75*</div>
    </div>
    <div class="card chart-card" style="flex:1.6">
      <div class="chart-title">LTV acumulado por cliente (€, cohorte madura)</div>
      <div class="chart">${lineChart([71,89,99,109,114,118,120],["M0","M2","M4","M6","M8","M10","M12"],C.green,140)}</div>
    </div>
  </div>
  <div class="note"><b style="color:${C.white}">Mes 0 ~€70 → Mes 12 ~€120 (+71%).</b> Recompra persistente 9–11 meses (haircare). El blended CAC (€7,70) está inflado por orgánico; con iCAC realista al escalar (€30–50*), LTGP:CAC = 1,5–2,5x → zona óptima.</div>`));

// S6 ICP
slides.push(wrap(6,"05 · ICP & hub de adquisición","El hub: mujeres 35–54",`
  <div class="split">
    <div class="card chart-card" style="flex:1.5">
      <div class="chart-title">% de compras pagadas por edad</div>
      <div class="chart">${hBars([1.9,15.5,30.7,38.4,11.2,2.1],["18-24","25-34","35-44","45-54","55-64","65+"],C.gold)}</div>
    </div>
    <div class="col-cards">
      <div class="card pc"><div class="pc-v" style="color:${C.green}">69%</div><div class="pc-l">de las compras = 35–54 años · ROAS ~10,5x</div></div>
      <div class="card pc"><div class="pc-v" style="color:${C.gold}">97,5%</div><div class="pc-l">mujeres. Marca de mujer.</div></div>
      <div class="card pc"><div class="pc-v" style="color:${C.white};font-size:30px">25–34</div><div class="pc-l">la palanca de escala (ROAS 10,5x)</div></div>
    </div>
  </div>
  <div class="note">55+ pierde eficiencia (ROAS 7–8x) → no forzar ahí.</div>`));

// S7 productos
slides.push(wrap(7,"06 · Productos","El motor son productos baratos de volumen",`
  <div class="split">
    <table class="tbl" style="flex:1.6">
      <tr><th>Producto</th><th>Net €</th><th>Pedidos</th><th>€/ped</th></tr>
      ${[["BOND, J'AIME BOND","88.480","4.195","€21"],["Mascarilla One Minute Wonder","87.154","2.861","€30"],
         ["Champú Gorgeous Hair","53.303","1.907","€28"],["Champú Bathman Detox","47.360","1.622","€29"],
         ["Clandestino DUO (bundle)","37.094","1.065","€35"]]
        .map(r=>`<tr><td class="lft">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td style="color:${C.gold}">${r[3]}</td></tr>`).join("")}
    </table>
    <div class="card warn">
      <div class="warn-h">⚠ Sesgo del algoritmo</div>
      <div class="warn-b">Meta optimiza a CPA bajo y empuja los productos baratos (BOND €21).</div>
      <div class="warn-m">Falta ver contribución por SKU (requiere COGS reales) y segmentar por unit economics, no por CPA.</div>
    </div>
  </div>
  <div class="note">Los bundles (DUO, Ritual, Packs €35–45) ya existen pero pesan poco → palanca de AOV clara (slide siguiente).</div>`));

// S8 AOV
slides.push(wrap(8,"07 · Gap de AOV","Subir el AOV con bundles habilita más spend rentable",`
  <div class="aov-row">
    <div class="card aovc"><div class="aov-l">AOV actual</div><div class="aov-v">€53,6</div></div>
    <div class="arrow">→</div>
    <div class="card aovc"><div class="aov-l">AOV potencial (+15%)</div><div class="aov-v" style="color:${C.green}">€61,7</div></div>
    <div class="card chain">
      <div class="chain-h">Efecto en cadena</div>
      <div class="chain-i"><span style="color:${C.green}">+€22–59K*</span> contribución / año</div>
      <div class="chain-i">↓ breakeven ROAS</div>
      <div class="chain-i">↑ spend rentable</div>
    </div>
  </div>
  <div class="note" style="max-width:62%">Los bundles ya existen (DUO, Ritual, Packs) pero los top-sellers son singles baratos (BOND €21, Mascarilla €30). Empujarlos sube el AOV, baja el breakeven y aprovecha el LTV que dobla el primer pedido — círculo virtuoso.</div>`));

// S9 forecasting
slides.push(wrap(9,"08 · Creative forecasting","El cuello de botella es el presupuesto, no el creativo",`
  <div class="row4">
    ${[["28%","Win rate","benchmark >20% = excepcional",C.green],
       ["44 / 62","ads ≥€50 con ROAS >6x","calidad altísima",C.white],
       ["30%","Test tax","sano (alerta ~50%)",C.white],
       ["3%","spend en top-funnel","casi todo harvesting",C.red]]
      .map(s=>`<div class="card stat sm"><div class="big sm" style="color:${s[3]}">${s[0]}</div><div class="lbl-b">${s[1]}</div><div class="lbl-m">${s[2]}</div></div>`).join("")}
  </div>
  <div class="card band"><b style="color:${C.gold}">Tenéis 56 anuncios rentables ahogados a ~€1,5/día.</b> Hit rate excepcional → la palanca es meter presupuesto, no producir más creativo. Para escalar sin romper ROAS: subir budget/winner + inyectar top-funnel/Unaware.</div>
  <div class="note">Winners: Founder-led talking head · M054 Oferta/Urgencia · K042 BOND · Antifrizz · Rapunhair/caída · colab influencer Berta×Zubi. · Formato: Static 39% / Video 35% / Carousel 6%.</div>`));

// S10 CPM
slides.push(wrap(10,"09 · CPMs al alza","El reloj corre en contra: el CPM ya sube +50%",`
  <div class="split">
    <div class="card chart-card" style="flex:1.7">
      <div class="chart-title">CPM mensual (€)</div>
      <div class="chart">${lineChart([3.95,3.99,4.85,4.23,5.63,5.93],["Ene","Feb","Mar","Abr","May","Jun*"],C.red,7)}</div>
    </div>
    <div class="col-cards">
      <div class="card pc"><div class="pc-v" style="color:${C.red}">+50%</div><div class="pc-l">CPM Ene €3,95 → Jun €5,93</div></div>
      <div class="card pc"><div class="pc-v" style="color:${C.gold}">6–12x</div><div class="pc-l">frecuencia alta = satura la audiencia core</div></div>
      <div class="card pc"><div class="pc-v" style="color:${C.white};font-size:30px">~€10</div><div class="pc-l">CPA proyectado en 12m si el CPM sigue</div></div>
    </div>
  </div>
  <div class="note" style="color:${C.red}">Cada mes que esperamos, invertir cuesta más caro. Escalar ahora bloquea inventario barato y reparte el coste del aprendizaje antes de que suba el suelo.</div>`));

// S11 proyecciones
slides.push(wrap(11,"10 · Proyecciones","Cada € extra deja contribución — la frontera está lejos",`
  <table class="tbl wide">
    <tr><th>Escenario</th><th>Spend Meta / mes</th><th>Contrib. inc. (iROAS 4x*)</th><th>Contrib. inc. (iROAS 6x*)</th></tr>
    ${[["Actual","€3.870","—","—"],["+50%","€5.805","+€2.900","+€5.320"],
       ["+100%","€7.740","+€5.805","+€10.640"],["+200%","€11.610","+€11.610","+€21.290"]]
      .map(r=>`<tr><td class="lft">${r[0]}</td><td>${r[1]}</td><td style="color:${C.green}">${r[2]}</td><td style="color:${C.green}">${r[3]}</td></tr>`).join("")}
  </table>
  <div class="card band"><b style="color:${C.gold}">Profit frontier:</b> se invierte mientras el ROAS marginal &gt; 1,6x (breakeven). Hoy el medio es ~10x → hay muchísimo recorrido. Cada € extra a iROAS 4x* deja +€1,50 de contribución.</div>`));

// S12 dinero
slides.push(wrap(12,"11 · Dinero sobre la mesa","Lo que nos estamos dejando: €90–130K / año",`
  <div class="card band band2"><span class="band-big">≈ €90–130K</span><span class="band-txt">de contribución al año*, repartido en tres palancas — todas activables.</span></div>
  <div class="row3 levers">
    ${[["SPEND","+€35–64K","Doblar el paid alimentando winners (iROAS 4x)",C.green],
       ["AOV","+€22–59K","Empujar bundles (+15% de AOV)",C.gold],
       ["CR","+€32K","CRO en los meses valle (+0,5pp de CVR)",C.white]]
      .map(l=>`<div class="card lever"><div class="lever-top" style="background:${l[3]}"></div><div class="lever-k" style="color:${l[3]}">${l[0]}</div><div class="lever-v">${l[1]}</div><div class="lever-d">${l[2]}</div></div>`).join("")}
  </div>
  <div class="note">Las palancas se potencian entre sí: subir el AOV baja el breakeven → habilita más spend → que aprovecha el LTV que dobla el primer pedido.</div>`));

// S13 que puede pasar
slides.push(wrap(13,"12 · Qué puede pasar","Dos caminos — y no actuar también tiene precio",`
  <div class="two">
    <div class="card scen"><div class="sbar" style="background:${C.green}"></div><div class="scen-h" style="color:${C.green}">ESCENARIO A · ACTUAR</div>
      <ul><li>Capturamos los €90–130K/año de contribución.</li><li>Construimos el motor con el CPM aún en ~€5, no en €8.</li><li>El top-funnel baja CPM/frecuencia y trae cliente incremental.</li><li>El LTV de €120 justifica pagar más por adquirir → crecemos en clientes nuevos.</li></ul></div>
    <div class="card scen"><div class="sbar" style="background:${C.red}"></div><div class="scen-h" style="color:${C.red}">ESCENARIO B · SEGUIR IGUAL</div>
      <ul><li>El CPM sigue +~50%/año → el margen se comprime solo.</li><li>La frecuencia (ya 6–12x) satura la audiencia core → cae el ROAS de valle.</li><li>Dejamos de captar el cliente nuevo que el LTV justifica.</li><li>Coste de inacción: ~€22–32K de contribución por trimestre de espera*.</li></ul></div>
  </div>
  <div class="closer">Con los CPMs subiendo, no escalar no es "mantener" — es retroceder en cámara lenta.</div>`));

// S14 crecimiento YoY (insight clienta)
slides.push(wrap(14,"13 · Crecimiento YoY","El crecimiento es cliente nuevo — y Meta es ese canal",`
  <div class="row4">
    ${[["+23%","Online Store","vs 2025 (total sales)",C.green],
       ["−15%","Tapcart (app)","vs 2025",C.red],
       ["+34%","Clientes nuevos","+26% en facturación",C.green],
       ["+13%","Clientes recurrentes","pero su € está plano (−1%)",C.gold]]
      .map(s=>`<div class="card stat sm"><div class="big sm" style="color:${s[3]};font-size:40px">${s[0]}</div><div class="lbl-b">${s[1]}</div><div class="lbl-m">${s[2]}</div></div>`).join("")}
  </div>
  <div class="card band"><b style="color:${C.green}">Todo el crecimiento viene de CLIENTE NUEVO:</b> +34% en número, +26% en facturación. El recurrente sube en número (+13%) pero su gasto está plano (−1%) — y su canal, la app (Tapcart), cae −15%.</div>
  <div class="ins"><b style="color:${C.gold}">Meta es el canal que trae al cliente nuevo y llena Online Store.</b> <span style="color:${C.mute}">La fuga no es la adquisición — es la retención en la app. Mover presupuesto fuera de Meta frenaría justo el motor que crece.</span></div>
  <div class="note" style="color:${C.dim};font-style:italic">Inversión Meta H1: €9,5K (2025) → €23,2K (2026), +144%. Subimos el paid y fue justo a lo que crece.</div>`));

// S15 escenario cliente realidad
slides.push(wrap(15,"14 · Escenario cliente","¿Mover todo el paid (€6K/mes) a TikTok Shop?",`
  <div class="card band band-prop"><b style="color:${C.red}">La propuesta:</b> reasignar los ~€6K/mes de paid de Meta a TikTok Shop y dejar Meta a €0.</div>
  <div class="subh" style="color:${C.gold}">La realidad de TikTok Shop hoy (canal Silk) — verificada en vivo, y es BUENA:</div>
  <div class="row3">
    ${[["€7.238","GMV TikTok Shop · últimos 30d<br>(254 pedidos · AOV €28)",C.green],
       ["~12x","ROAS a €20/día<br>(gross; ~9x net)",C.green],
       ["€0 → €7K","en el último mes<br>(el canal está despegando)",C.gold]]
      .map(s=>`<div class="card stat"><div class="big" style="color:${s[2]};font-size:38px">${s[0]}</div><div class="lbl-m" style="margin-top:14px">${s[1]}</div></div>`).join("")}
  </div>
  <div class="note"><b style="color:${C.white}">TikTok Shop es un winner real a pequeña escala.</b> <span style="color:${C.gold};font-style:italic">La pregunta no es SI crecerlo (hay que hacerlo) — es CÓMO. Y matar Meta para financiarlo no es el cómo.</span></div>`));

// S16 escenario cliente matematica
slides.push(wrap(16,"15 · Escenario cliente","Por qué mover todo a TikTok destruye valor — con números",`
  <table class="tbl wide">
    <tr><th>ROAS TikTok @ €6K/mes</th><th>Revenue TikTok</th><th>vs HOY combinado (~€38K/mes)</th></tr>
    <tr><td class="lft">12x (se mantiene — fantasía a 10×)</td><td>€72K</td><td style="color:${C.mute}">+€34K (irreal)</td></tr>
    <tr><td class="lft">5x (generoso)</td><td>€30K</td><td style="color:${C.gold};font-weight:bold">−€8K/mes</td></tr>
    <tr><td class="lft">3x (realista a 10×)</td><td>€18K</td><td style="color:${C.red};font-weight:bold">−€20K/mes (−€240K/año)</td></tr>
  </table>
  <div class="note2">HOY: Meta €3,9K/mes → ~€31K + TikTok €0,6K/mes → €7,2K = ~€38K combinado. El plan lo cambia por TikTok solo. Por qué el ROAS no aguanta 10×: a €20/día recoges la demanda más caliente; al escalar, el CPA sube y el ROAS cae (en Meta, freq 12x → ROAS 7x). Es saturación, no opinión.</div>
  <div class="grid2 args">
    ${[["Cambias lo probado por lo no probado","Meta: ROAS 7–16x, win rate 28%, hub 35–54, feed del LTV €120.",C.gold],
       ["Concentración 100% en canal naciente","TikTok Shop ES inmaduro → riesgo plataforma / región.",C.gold],
       ["Audiencia más joven","Peor encaje con haircare €50 de recompra (LTV/retención inciertas).",C.gold],
       ["Diversificar SUMANDO, no amputando","Crecer TikTok con budget incremental cuando aguante — sin matar Meta.",C.green]]
      .map(a=>`<div class="card arg"><div class="abar" style="background:${a[2]}"></div><div class="arg-h" style="color:${a[2]===C.green?C.green:C.white}">${a[0]}</div><div class="arg-d">${a[1]}</div></div>`).join("")}
  </div>
  <div class="fn"><b style="color:${C.gold}">Y no es comparar lo mismo:</b> el 12x de TikTok es ROAS gross a microescala (cesta €28, mucha recompra); el 8,13x de Meta es NC-ROAS — cliente nuevo, a escala real. El new-customer ROAS de TikTok a €6K/mes caería por debajo del de Meta.</div>`));

// S17 cobertura creativa (awareness x angulos)
slides.push(wrap(17,"16 · Cobertura creativa","Dónde metemos el creativo — y qué rinde",`
  <div class="split" style="align-items:flex-start;margin-top:22px">
    <div style="flex:1">
      <div class="coltitle">POR NIVEL DE AWARENESS</div>
      <table class="tbl">
        <tr><th>Nivel</th><th>% gasto</th><th>ROAS</th></tr>
        <tr><td class="lft">Problem aware</td><td>36%</td><td>7,2x</td></tr>
        <tr><td class="lft">Solution aware</td><td>29%</td><td>9,9x</td></tr>
        <tr><td class="lft">Sin tag</td><td>29%</td><td>9,5x</td></tr>
        <tr><td class="lft">Unaware (top-funnel)</td><td style="color:${C.red}">4%</td><td>6,2x</td></tr>
        <tr><td class="lft">Product (retarget)</td><td>2%</td><td style="color:${C.green}">71,8x</td></tr>
      </table>
    </div>
    <div style="flex:1.2">
      <div class="coltitle">POR ÁNGULO GANADOR</div>
      <table class="tbl">
        <tr><th>Ángulo</th><th>% gasto</th><th>ROAS</th></tr>
        <tr><td class="lft">Reparación / pelo dañado</td><td>19%</td><td>7,8x</td></tr>
        <tr><td class="lft">Autoridad del fundador (Moncho)</td><td>18%</td><td style="color:${C.green};font-weight:bold">16,3x</td></tr>
        <tr><td class="lft">Oferta / pack / urgencia</td><td>15%</td><td>10,6x</td></tr>
        <tr><td class="lft">Control del frizz</td><td>12%</td><td>9,0x</td></tr>
        <tr><td class="lft">Anti-caída / crecimiento</td><td>8%</td><td style="color:${C.red}">6,2x</td></tr>
        <tr><td class="lft">Brillo / pelo bonito</td><td>2%</td><td>10,5x</td></tr>
      </table>
    </div>
  </div>
  <div class="note"><b style="color:${C.green}">El contenido del fundador (Moncho) es el de mayor ROAS — 16,3x con solo el 18% del gasto.</b> Ahí hay que escalar, y es el puente perfecto con el contenido orgánico de TikTok. Solo 4% en top-funnel (palanca clara) y "Brillo" infrainvertido (2% a 10,5x).</div>`));

// S18 analisis ICP
slides.push(wrap(18,"17 · Análisis de ICP","Nuestros ICPs: a quién le hablamos y qué rinde",`
  <table class="tbl wide">
    <tr><th>ICP / Persona</th><th>Necesidad (ángulo)</th><th>% gasto</th><th>ROAS</th></tr>
    <tr><td class="lft">Fan de Moncho</td><td class="lft" style="font-weight:normal;color:${C.mute}">Autoridad del fundador</td><td>18%</td><td style="color:${C.green};font-weight:bold">16,3x ★</td></tr>
    <tr><td class="lft">La Reparadora</td><td class="lft" style="font-weight:normal;color:${C.mute}">Pelo dañado · BOND</td><td>19%</td><td>7,8x</td></tr>
    <tr><td class="lft">Cazadora de packs</td><td class="lft" style="font-weight:normal;color:${C.mute}">Oferta / bundle</td><td>15%</td><td>10,6x</td></tr>
    <tr><td class="lft">La Anti-frizz</td><td class="lft" style="font-weight:normal;color:${C.mute}">Control del encrespado</td><td>12%</td><td>9,0x</td></tr>
    <tr><td class="lft">La Anti-caída</td><td class="lft" style="font-weight:normal;color:${C.mute}">Pérdida / crecimiento</td><td>8%</td><td style="color:${C.red}">6,2x</td></tr>
    <tr><td class="lft">La de Brillo</td><td class="lft" style="font-weight:normal;color:${C.mute}">Pelo bonito (infrainvertida)</td><td>2%</td><td>10,5x</td></tr>
  </table>
  <div class="ins"><b style="color:${C.green}">Hub: mujer 35–54 (97,5% female).</b> Dentro hay 6 need-states. La "Fan de Moncho" es la más rentable (16,3x) → ahí escalar. "Brillo" infrainvertida con buen ROAS; "Anti-caída" la más floja.</div>
  <div class="note" style="font-style:italic">Con Advantage+ broad el algoritmo asigna el gasto; el ICP se expresa por el ÁNGULO que resuena → optimizamos por mensaje, no por audiencia.</div>`));

// S19 plan
slides.push(wrap(19,"18 · Plan de acción","Cinco pasos priorizados",`
  <div class="plan">
  ${[["Puente creativo Meta ↔ TikTok Shop","Llevar el contenido del fundador (16,3x ROAS, el que petó en TikTok) a Meta y escalar. Sin canibalizar presupuesto.","Creative + Media buyer"],
     ["Medir incrementalidad","Geo-holdout antes de escalar a saco — separar incremental de harvesting.","MLO Analytics"],
     ["Inyectar top-funnel / Unaware al 100%","De 4% → 15–20% + nuevos ángulos para captar demanda nueva.","Creative"],
     ["Desarrollar la vertical de PACKS","PDPs específicas para packs → subir AOV (palanca hoy infrautilizada).","CRO + Media buyer"],
     ["Construir KPI Panel con COGS reales","Cierra breakeven, contribución por SKU y el LTGP:CAC definitivo.","Marcel / Manu"]]
    .map((s,i)=>`<div class="step"><div class="num ${i<2?'on':''}">${i+1}</div><div class="step-txt"><div class="step-h">${s[0]}</div><div class="step-d">${s[1]}</div></div><div class="step-o">${s[2]}</div></div>`).join("")}
  </div>`));

const css = `
*{margin:0;padding:0;box-sizing:border-box;}
@page{size:1280px 720px;margin:0;}
body{background:${C.bg};font-family:"Helvetica Neue",Arial,sans-serif;}
.slide{position:relative;width:1280px;height:720px;background:${C.bg};overflow:hidden;page-break-after:always;padding:46px 56px 0;}
.kicker{color:${C.gold};font-size:14px;font-weight:bold;letter-spacing:3px;display:flex;align-items:center;}
.kicker .sq{width:11px;height:11px;background:${C.gold};display:inline-block;margin-right:11px;}
.title{font-family:Georgia,serif;color:${C.white};font-size:33px;font-weight:bold;margin-top:14px;line-height:1.15;}
.footer{position:absolute;left:0;right:0;bottom:24px;text-align:center;color:${C.dim};font-size:10px;}
.pageno{position:absolute;right:56px;bottom:22px;color:${C.dim};font-size:11px;}
.flogo{position:absolute;left:56px;bottom:16px;height:26px;}
.cv-logo{position:absolute;top:74px;left:60px;height:52px;}
.card{background:${C.card};border:1px solid ${C.line};border-radius:11px;box-shadow:0 5px 14px rgba(0,0,0,.35);position:relative;overflow:hidden;}
.note{color:${C.mute};font-size:15px;font-style:italic;position:absolute;left:56px;right:56px;bottom:58px;line-height:1.4;}
.note.big-note{font-style:normal;font-size:17px;}
.note2{color:${C.mute};font-size:14px;font-style:italic;margin-top:14px;line-height:1.4;}
.row3{display:flex;gap:18px;margin-top:30px;}
.row4{display:flex;gap:16px;margin-top:28px;}
.stat{flex:1;padding:22px 24px;}
.stat .big{font-family:Georgia,serif;font-size:46px;font-weight:bold;line-height:1;}
.stat .big.sm{font-size:34px;}
.stat.sm{padding:18px 20px;}
.lbl-b{color:${C.white};font-weight:bold;font-size:14px;margin-top:12px;}
.lbl-m{color:${C.mute};font-size:11.5px;margin-top:5px;line-height:1.35;}
.bullets{list-style:none;margin-top:34px;}
.bullets li{color:${C.white};font-size:16px;margin-bottom:15px;padding-left:20px;position:relative;}
.bullets li:before{content:"•";color:${C.gold};position:absolute;left:0;}
.split{display:flex;gap:26px;margin-top:26px;align-items:stretch;}
.col-stats{flex:.85;display:flex;flex-direction:column;justify-content:space-between;}
.kpi-v{font-family:Georgia,serif;font-size:31px;font-weight:bold;}
.kpi-l{color:${C.mute};font-size:12px;margin-top:3px;margin-bottom:8px;}
.chart-card{flex:1.5;padding:18px 20px;display:flex;flex-direction:column;}
.chart-title{color:${C.white};font-size:13px;font-weight:bold;margin-bottom:8px;}
.chart{flex:1;min-height:0;}
.tbl{border-collapse:separate;border-spacing:0;width:100%;flex:1;}
.tbl th{background:${C.greenD};color:${C.white};font-size:13px;font-weight:bold;padding:11px 12px;text-align:center;}
.tbl th:first-child{text-align:left;border-top-left-radius:8px;}
.tbl th:last-child{border-top-right-radius:8px;}
.tbl td{background:${C.card};color:${C.mute};font-size:14px;padding:11px 12px;text-align:center;border-bottom:1px solid ${C.bg};}
.tbl tr:nth-child(even) td{background:${C.card2};}
.tbl td.lft{color:${C.white};text-align:left;font-weight:bold;}
.tbl td.hl,.tbl th.hl{color:${C.gold};font-weight:bold;}
.tbl.wide{margin-top:30px;}
.tnote{color:${C.dim};font-size:11px;font-style:italic;margin-top:8px;}
.grid2{flex:1;display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.mini{padding:16px 18px;}
.mini-v{font-family:Georgia,serif;font-size:26px;font-weight:bold;}
.mini-l{color:${C.mute};font-size:11px;margin-top:6px;}
.decisive{flex:.8;padding:24px;display:flex;flex-direction:column;justify-content:center;}
.dec-lbl{color:${C.mute};font-weight:bold;font-size:14px;}
.dec-big{font-family:Georgia,serif;color:${C.green};font-size:74px;font-weight:bold;line-height:1;margin:6px 0;}
.dec-zone{color:${C.gold};font-style:italic;font-size:14px;}
.dec-sub{color:${C.mute};font-size:12px;margin-top:8px;}
.col-cards{flex:1;display:flex;flex-direction:column;gap:14px;}
.pc{padding:14px 20px;flex:1;display:flex;flex-direction:column;justify-content:center;}
.pc-v{font-family:Georgia,serif;font-size:36px;font-weight:bold;}
.pc-l{color:${C.mute};font-size:12px;margin-top:4px;}
.warn{flex:.9;padding:20px;}
.warn-h{color:${C.gold};font-weight:bold;font-size:14px;}
.warn-b{color:${C.white};font-size:13px;margin-top:12px;line-height:1.4;}
.warn-m{color:${C.mute};font-size:13px;margin-top:12px;line-height:1.4;}
.aov-row{display:flex;gap:18px;margin-top:30px;align-items:center;}
.aovc{padding:20px 24px;width:230px;}
.aov-l{color:${C.mute};font-size:13px;}
.aov-v{font-family:Georgia,serif;font-size:46px;font-weight:bold;color:${C.white};margin-top:6px;}
.arrow{color:${C.gold};font-size:40px;font-weight:bold;}
.chain{flex:1;padding:18px 22px;background:${C.card2};}
.chain-h{color:${C.gold};font-weight:bold;font-size:14px;margin-bottom:10px;}
.chain-i{color:${C.white};font-size:17px;font-weight:bold;margin:8px 0;}
.band{background:${C.card2};border:1px solid ${C.line};border-radius:11px;padding:18px 24px;color:${C.white};font-size:16px;margin-top:26px;line-height:1.4;}
.band2{display:flex;align-items:center;gap:24px;}
.band-big{font-family:Georgia,serif;font-size:50px;font-weight:bold;color:${C.green};}
.band-txt{font-size:15px;color:${C.white};}
.band-prop{margin-top:24px;font-size:15px;}
.ins{margin-top:22px;font-size:15px;line-height:1.45;color:#C2D2C8;}
.coltitle{color:${C.green};font-size:12px;font-weight:bold;letter-spacing:1px;margin-bottom:8px;}
.levers{margin-top:22px;}
.lever{flex:1;padding:24px 22px 18px;}
.lever-top{position:absolute;top:0;left:0;right:0;height:6px;}
.lever-k{font-weight:bold;font-size:13px;letter-spacing:2px;margin-top:6px;}
.lever-v{font-family:Georgia,serif;font-size:32px;font-weight:bold;color:${C.white};margin:8px 0;}
.lever-d{color:${C.mute};font-size:12px;}
.two{display:flex;gap:20px;margin-top:24px;}
.scen{flex:1;padding:24px 24px 24px 30px;}
.sbar{position:absolute;top:0;left:0;bottom:0;width:7px;}
.scen-h{font-weight:bold;font-size:15px;letter-spacing:1px;margin-bottom:14px;}
.scen ul{list-style:none;}
.scen li{color:${C.white};font-size:13.5px;margin-bottom:13px;padding-left:16px;position:relative;line-height:1.35;}
.scen li:before{content:"•";color:${C.gold};position:absolute;left:0;}
.closer{position:absolute;left:56px;right:56px;bottom:48px;text-align:center;color:${C.gold};font-family:Georgia,serif;font-style:italic;font-weight:bold;font-size:17px;}
.subh{font-size:13px;font-weight:bold;margin-top:18px;margin-bottom:-6px;}
.args{margin-top:16px;grid-template-columns:1fr 1fr;gap:14px;}
.arg{padding:12px 14px 12px 22px;}
.abar{position:absolute;top:0;left:0;bottom:0;width:6px;}
.arg-h{font-weight:bold;font-size:13.5px;}
.arg-d{color:${C.mute};font-size:11.5px;margin-top:5px;line-height:1.3;}
.fn{position:absolute;left:56px;right:56px;bottom:52px;color:${C.mute};font-size:11px;font-style:italic;line-height:1.35;}
.plan{margin-top:24px;}
.step{display:flex;align-items:center;gap:18px;padding:11px 0;border-bottom:1px solid ${C.line};}
.num{width:46px;height:46px;border-radius:50%;border:1px solid ${C.gold};color:${C.gold};font-family:Georgia,serif;font-size:22px;font-weight:bold;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.num.on{background:${C.gold};color:${C.bg};}
.step-txt{flex:1;}
.step-h{color:${C.white};font-size:16px;font-weight:bold;}
.step-d{color:${C.mute};font-size:12.5px;margin-top:3px;}
.step-o{color:${C.gold};font-size:12.5px;font-weight:bold;text-align:right;width:170px;flex-shrink:0;}
/* cover */
.cover{padding:0;}
.cover .goldbar{position:absolute;top:0;right:150px;width:15px;height:720px;background:${C.gold};}
.cover .goldbar:after{content:"";position:absolute;left:30px;top:0;width:5px;height:720px;background:${C.gold};opacity:.4;}
.cv-kick{position:absolute;top:80px;left:60px;color:${C.gold};font-weight:bold;letter-spacing:4px;font-size:13px;}
.cv-brand{position:absolute;top:215px;left:58px;font-family:Georgia,serif;font-size:62px;font-weight:bold;color:${C.white};}
.cv-sub{position:absolute;top:320px;left:60px;font-family:Georgia,serif;font-style:italic;font-size:26px;color:${C.gold};}
.cv-rule{position:absolute;top:392px;left:62px;width:230px;height:2px;background:${C.line};}
.cv-meta1{position:absolute;top:415px;left:60px;color:${C.white};font-size:16px;}
.cv-meta2{position:absolute;top:448px;left:60px;color:${C.mute};font-size:12px;}
.cv-foot{position:absolute;bottom:40px;left:60px;color:${C.dim};font-size:10px;}
`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>${css}</style></head><body>${slides.join("")}</body></html>`;
fs.writeFileSync("deck.html", html);

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: "new", args: ["--no-sandbox"],
  });
  const page = await browser.newPage();
  await page.goto("file://" + process.cwd() + "/deck.html", { waitUntil: "networkidle0" });
  await page.pdf({
    path: "Moncho Moreno - Reporte Financiero e Inversion - Ene-Jun 2026.pdf",
    width: "1280px", height: "720px", printBackground: true, pageRanges: "1-19",
  });
  await browser.close();
  console.log("PDF WRITTEN");
})();
