---
name: kpi-panel-builder
description: "Expert agent for building and maintaining KPI Panels (Breakeven ROAS, Target CPA, Unit Economics) for ecommerce DTC brands managed by MLO Growth. ALWAYS use this skill when the user mentions: KPI panel, panel de KPIs, breakeven ROAS, breakeven CPA, target ROAS, target CPA, unit economics, metricas de corte, contribution margin, margen de contribucion, crear panel, actualizar panel, revision de KPIs, wave surfing thresholds, or any request related to calculating advertising profitability thresholds for an ecommerce brand. Also trigger when: a new brand completes onboarding and needs its KPI panel built, the user asks to update KPIs after price/cost changes, or the user wants to compare advertising performance against profitability benchmarks. Even partial requests like 'hazme los KPIs de X' or 'cual es el breakeven de X' or 'actualiza los margenes' should trigger this skill."
---

# KPI Panel Builder — Ecommerce DTC Paid Media

Expert agent for constructing and maintaining KPI Panels that translate a brand's real cost structure into actionable advertising thresholds (Breakeven ROAS, Target CPA, etc.) for Meta Ads, Google Ads, and other paid channels.

## Why This Matters

Without this panel, every optimization decision is an opinion. With it, it's math. No euro of ad spend should be managed without knowing the brand's Breakeven ROAS and Target CPA.

## Core Principle

The KPI Panel converts a brand's unit economics (AOV, COGS, shipping, payment fees) into advertising decision thresholds that tell media buyers exactly when to scale, hold, or kill a campaign.

## Inputs Required

Before building any panel, gather these data points. Read the brand's onboarding form, Brand DNA page in Notion, and any kick-off call notes.

### Critical (panel cannot be built without these)
- **AOV (Average Order Value)** — from Shopify or onboarding form
- **COGS % sobre PVP** — from onboarding or pricing document
- **Shipping cost per order** — from logistics provider info
- **Gross margin %** — from onboarding or accounting

### Important (improve accuracy)
- Payment commission % (Shopify Payments / Stripe — default 2% if unknown)
- Monthly order volume (Shopify Analytics)
- Monthly revenue (Shopify / P&L)
- Monthly ad budget
- Historical ROAS/CPA by channel (if available)

### Useful (for advanced panels)
- Full pricing catalog (SKU-level PVP)
- COGS breakdown by product line
- Return/cancellation rates
- LTV data (Triple Whale / Klaviyo)
- Top 5 SKUs by sales volume

## Where to Find the Data

1. **Notion** → Brand portal → Research section → Brand DNA page (section "Metricas de negocio clave")
2. **Notion** → Brand portal → Onboarding Checklist
3. **Google Drive** → Brand folder → DRIVE ECOSYSTEM → ONBOARDING → ONBOARDING FORM
4. **Notion** → Calls database → Kick-Off call notes
5. **Google Drive** → Brand folder → DRIVE ECOSYSTEM → UNIT ECONOMICS folder

## The Math — Formulas

### Cost Structure Per Order
```
COGS (€) = AOV × COGS%
Payment Commission (€) = AOV × Payment%  (default 2%)
Total Variable Cost (€) = COGS + Shipping + Payment Commission
Contribution Margin (€) = AOV − Total Variable Cost
Contribution Margin (%) = CM(€) / AOV
Max Ad Spend Per Order = Contribution Margin (€)
```

### Advertising Cut-Off Metrics
```
Breakeven ROAS = AOV / Contribution Margin (€)
   → Floor: below this, the brand LOSES money on every order

Min Tolerable ROAS = AOV / (CM − Min_Margin% × AOV)
   → Safety buffer (default Min_Margin = 10%)

Target ROAS = AOV / (CM − Target_Margin% × AOV)
   → Desired profitability (default Target_Margin = 20%)

Target ROAS at Scale = AOV / (CM − Scale_Margin% × AOV)
   → Profitability with volume efficiency (default Scale_Margin = 25%)

Breakeven CPA (€) = Contribution Margin (€)
   → Absolute maximum CPA

Max Tolerable CPA (€) = CM − (Min_Margin% × AOV)

Target CPA (€) = CM − (Target_Margin% × AOV)

Target CPA at Scale (€) = CM − (Scale_Margin% × AOV)
```

### Standard Margin Targets (DTC Ecommerce)
- Minimum tolerable: 10%
- Target: 20%
- At scale: 25%

Adjust based on business model and growth stage.

## Excel Panel Structure (4 tabs)

### Tab 1: ⚙️ Inputs
All editable assumptions. Blue font for inputs the user can change.
Contains: AOV, COGS%, shipping cost, payment commission %, margin targets, ad budget, order volume.

### Tab 2: 📊 KPIs Blended
Main panel with calculated metrics:
- Cost structure breakdown (COGS, shipping, payment, CM)
- Breakeven ROAS / Min / Target / Scale ROAS
- Breakeven CPA / Max Tolerable / Target / Scale CPA
- Monthly projection with budget (estimated orders, revenue, profit at different ROAS levels)

### Tab 3: 📡 KPIs por Canal
Comparative panel for Meta / Google / TikTok with channel-specific adjustments if available.

### Tab 4: 🎯 Cockpit
Daily reference sheet — the one the media buyer opens every morning:
- Traffic light system: Red (below breakeven), Yellow (between breakeven and target), Green (above target)
- Key numbers at a glance
- Decision rules: when to scale, hold, or pause

## Red Flags to Check

After building the panel, validate these:
- **Breakeven ROAS > 3.5x** → Cost structure too heavy for paid scaling. Review COGS, logistics, or propose bundles to increase AOV.
- **AOV < 30€** → Hard to cover reasonable CPAs. Propose bundles or subscriptions.
- **COGS% > 50%** → Gross margin < 50% is dangerous for DTC paid.
- **Inconsistent data (AOV vs revenue vs orders don't match)** → Don't build until resolved.
- **Client doesn't know real COGS** → Estimate conservatively (higher) and flag as urgent assumption.

## When to Update

- Price changes or new SKU launches
- Logistics provider change or cost renegotiation
- Discount policy changes
- Quarterly assumption review (AOV drift)
- New channel added (create channel-specific panel)
- After Black Friday or seasonal peaks

## Delivery Checklist

After generating the panel:
- [ ] All inputs from real client data (not placeholders)
- [ ] COGS% validated
- [ ] Shipping cost confirmed
- [ ] Zero formula errors
- [ ] Breakeven ROAS sanity check (1.5x–2.5x is normal DTC)
- [ ] Assumptions documented in cell comments
- [ ] Category tabs if 2+ product lines with different AOV
- [ ] File named: `KPI Panel — {Brand} — {Month Year}.xlsx`

## Notion Announcement Template

After creating the panel, post an announcement in the brand's Communication Hub with this structure:

```
📊 KPI Panel — {Brand} ✅

### Los numeros que hay que saber de memoria
- 🔴 Breakeven ROAS: {X.XXx}
- CPA breakeven: {XX,XX €}
- 🟢 Target ROAS: {X.XXx}
- CPA target: {XX,XX €}
- Contribution Margin por pedido: {XX,XX € (XX,X%)}

### Estructura del archivo (4 pestanas)
- ⚙️ Inputs → la unica que se toca
- 📊 KPIs Blended → analisis central y proyeccion mensual
- 📡 KPIs por Canal → comparativa Meta / Google / TikTok
- 🎯 Cockpit → referencia diaria rapida

### Red flags activas
- {List any red flags identified}

### Regla clave
Cualquier cambio de datos → solo tocar Inputs. El resto calcula solo.
```

## Reference Files

- `references/sop-kpi-panel.md` — Full SOP document with detailed process steps
- `references/brands-template.json` — JSON template for brand financial data
