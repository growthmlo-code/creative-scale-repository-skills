---
name: mlo-creator-spend-report
description: >
  Genera el reporte de AD SPEND POR CREADOR de una marca con UGC en Meta: cuánto se ha gastado por creador
  en un periodo (t7d/t30d/etc.) + cuántos ads live tiene cada uno. Funciona parseando el nombre del creador
  al INICIO del nombre del ad (naming convention creator-first). Nació del encargo de 8hours (Mathias/Marina
  quieren ver cada semana el spend por creador). USA SIEMPRE esta skill (ES/EN) cuando pidan: "spend por
  creador de [marca]", "cuánto hemos gastado por creador", "reporte de creadores en Meta", "ad spend per
  creator", "cuántos ads live por creador", "reporte para Marina / 8hours creadores", "creator spend report".
  Reutilizable para cualquier marca con creadores (8hours, Bala di Gala, ZZEN…) cambiando la cuenta de Meta.
---

# M.L.O · Creator Ad-Spend Report (Meta → por creador)

Reporte de **cuánto gasta cada creador** en Meta y **cuántos ads live** tiene, en el periodo pedido. Se apoya en que **cada ad empieza por el nombre exacto del creador**. Detalle técnico y pipeline en `references/pipeline.md`.

## Qué hace
1. Tira de **Meta** los ads de la marca (level=ad, `amount_spent` + `name` + `effective_status`, `date_preset` t30d por defecto).
2. **Parsea el creador** = todo lo que va antes del primer `_` en el nombre del ad (quitando emoji/símbolos iniciales).
3. Agrega **spend por creador** + cuenta de ads **ACTIVE**; separa lo atribuible a creador de lo que está con nombre de código (no atribuible → a renombrar).
4. Entrega: tabla `Creador · Spend · Ads live · % del total` + **cobertura** (% del spend que sí lleva creador) + **xlsx** en la carpeta REPORTING de la marca.

## El naming convention (la clave — sin esto no funciona)
`CreatorName_RestoDelNaming` · CreatorName en **CamelCase, sin espacios ni `_` dentro** (`TaylorWillis`, no "Taylor Willis"). Ads sin creador (founder/brand/estáticos) → primer bloque fijo **la marca** (p. ej. `8HOURS`). El reporte agrupa por lo que va **antes del primer `_`**.

## Reglas
- El **gasto de Meta viene como string europeo** `"1.089,15 € (EUR)"` → parsear (quitar `€`/nbsp, `.`=miles, `,`=decimal). Ver pipeline.
- **Excluir tokens genéricos** que no son creadores (Sleep, Rise, Creator, Bundle, Static, Video) → van al bucket "sin creador".
- Ser honesto con la **cobertura**: si solo el X% del spend lleva creador, decirlo (el resto necesita renombrado).
- Cuentas Meta conocidas: **8HOURS = 1336199457035968** (EUR). Otras marcas → sacar con `ads_get_ad_accounts`.

## Automatización
Para dejarlo semanal: rutina cloud (skill `schedule`) que invoca esta skill cada lunes y **postea la tabla a Slack** + (si corre en el Mac de Marcel) regenera el xlsx en `…/8hours/REPORTING/`. En cloud no hay Drive montado → adjunta el sheet a Slack.

---
**Ficheros:** `references/pipeline.md` (comando Meta exacto, parseo de spend, script de agregación + xlsx). **Relacionado:** naming del CE ([[mlo-naming-convention]]), Creator Tracker del CE de 8hours.
