---
name: mlo-sistema-creativo-2026
description: El cerebro de estrategia creativa de M.L.O Growth para Meta Ads en la era Andromeda (2026). Contiene el sistema completo — por qué el creativo es la palanca, cómo funciona el algoritmo (entity ID, diversidad, soulmate theory), la arquitectura de conceptos (persona × ángulo × oferta), el framework 3A y su jerarquía de riesgo, los ángulos (EPIC), los niveles de awareness y sofisticación de mercado, los hooks y la curiosidad tangible, el scriptwriting/storytelling (human desires, curiosity loops, cut the fluff), los formatos y el ecosistema creativo, la producción a volumen, el framework de testing (learn vs earn, trim-the-fat, stop-loss, portfolio mix semanal), la lectura de datos (soft vs hard metrics, retención, naming convention), los tipos de winner e iteración (false/low-profile/grand slam, escaleras de iteración, 20% speculation, building blocks), el escalado (regla del 20%, CBO vs ASC+, fases 0→1.5M), el forecasting creativo (cuántos creativos para X gasto: hit rate, churn, half-life, test tax), la diversidad creativa (Andromeda/entity ID) y el uso de IA en el flujo. ALWAYS use this skill (ES/EN) cuando Marcel o el equipo pidan: "cómo estructuro el testing", "cuántos creativos necesito", "qué ángulo/hook/formato uso", "cómo itero un winner", "cómo escalo sin romper", "explícame el 3A / EPIC / awareness / entity ID / soulmate theory", "cómo hago un brief creativo", "diagnostica por qué no escala esta cuenta", "creative strategy 2026", "estrategia creativa Meta", o cuando haya que redactar formación, SOPs o lead magnets de estrategia creativa. Dispara también con peticiones parciales o coloquiales sobre testing, iteración, forecasting creativo, diversidad de creativo, storytelling de ads o el rol de creative strategist.
---

# Sistema Creativo M.L.O 2026 (Meta / Andromeda)

Este skill es el **cerebro de estrategia creativa** de M.L.O Growth. Reúne, sintetizado y en nuestra voz, todo el sistema para crear, testear y escalar creativo en Meta en la era del algoritmo Andromeda. Lo usamos para:

- **Escribir briefs** y decidir qué testear a continuación (el creative strategy = priorizar el próximo movimiento de mayor impacto).
- **Diagnosticar cuentas** (¿el cuello de botella es volumen o calidad? ¿por qué no escala?).
- **Formar al equipo** (media buyers, estrategas, editores).
- **Generar lead magnets, SOPs y documentos** para la carpeta de Drive y para clientes.

## Cómo usarlo

1. **Lee el cerebro completo** en `references/creative-strategy-brain.txt`. Es la fuente única de verdad: todos los frameworks, en orden lógico, con sus reglas y umbrales.
2. **Cruza siempre con el resto del sistema M.L.O**: definiciones de winner y KPIs en `[[mlo-estratega-creativo]]`, los 12 frameworks de guion en el Playbook de Scripting, el Árbol de Cascada (deseo→avatar→ángulo), la Matriz Andromeda (naming/estructura) y el preset FFM (hook rate, hold rate, CTR, ROAS).
3. **Adapta a la voz M.L.O**: frases cortas, sin anglicismos innecesarios, práctico, sin humo. Cuando produzcas material para cliente o lead magnet, cierra siempre con el CTA de auditoría gratuita (mlo-growth.com/adquisicion/metodolgia-mlo-growth-3).

## Regla de oro

**El sistema gana, no el genio.** Un estratega 6/10 dentro de un sistema 10/10 supera siempre a un 10/10 dentro de un sistema roto. Este cerebro ES ese sistema. La palanca es construir el proceso (research → brief → producir → testear → analizar → iterar → escalar) y hacer que gire cada semana.

## Origen

Destilado e internalizado a estándar M.L.O a partir de material de mercado sobre estrategia creativa en Meta 2026. Reescrito en su totalidad con nuestra terminología y ejemplos genéricos. Se mejora con el tiempo (versionado en el propio cerebro).
