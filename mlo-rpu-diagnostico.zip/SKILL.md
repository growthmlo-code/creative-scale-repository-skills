---
name: mlo-rpu-diagnostico
description: >
  El DIAGNÓSTICO de KPIs de M.L.O Growth que descompone el ROAS en su árbol —
  (CPM·CTR→CPC) × (CVR·AOV→RPU) — para responder LA pregunta operativa: ¿el cuello de botella
  está en el ANUNCIO (Ad Performance) o en la WEB (Website Performance)? Dado Meta + Shopify + Triple Whale
  de una marca, calcula CPC, RPU, front-end ROAS (RPU÷CPC), Front-End Profit (AOV×margen − CPA) y lo compara
  con el profit a 90 días (CLV), y señala dónde está el APALANCAMIENTO (RPU manda: CPC tiene suelo, RPU tiene techo).
  ALWAYS use this skill (ES/EN) cuando Marcel o el equipo pidan: "diagnóstico de KPIs de [marca]", "árbol de ROAS",
  "descompón el ROAS de [marca]", "por qué el ROAS engaña", "cuál es el cuello: ads o web", "es problema de creativo o de la web",
  "RPU / EPC de [marca]", "revenue per user", "front vs back-end de [marca]", "front-end ROAS", "cuánto gano por usuario",
  "sube CVR/AOV cuánto sube el ROAS", "KPI tree diagnosis", "decompose ROAS", "is the bottleneck creative or the site",
  "front-end vs 90-day profit", "where's the leverage". Dispara también con peticiones parciales o coloquiales sobre
  "por qué no escala aunque el CPC es bueno", "el ROAS es 2 pero no gano dinero", "diagnostícame los números de [marca]".
  COMPLEMENTA (no duplica) a mlo-ecom-financials-2026 (unit economics profundos: LTGP:CAC, MER, break-even, P&L, caja),
  mlo-scale-report (deck de inversión), mlo-cfo-advisor (finanzas dirección) y mlo-cro-2026 (testing on-site); a esas defiere
  la profundidad de rentabilidad. Esto es el diagnóstico RÁPIDO del árbol de KPIs y el triage ads-vs-web.
---
# RPU Diagnóstico — el árbol de KPIs de MLO

## Qué hace
Coge los números reales de una marca (Meta + Shopify + Triple Whale) y **descompone el ROAS en su árbol** para localizar el cuello de botella en 5 minutos. La tesis: el ROAS es un número compuesto que **engaña** — dos marcas con el mismo ROAS 2.0x pueden tener enfermedades opuestas (una tiene el anuncio roto, otra la web rota). El árbol separa las dos mitades:

```
                         ROAS
            ┌──────────────┴──────────────┐
      AD PERFORMANCE                 WEBSITE PERFORMANCE
      (pre-click)                    (post-click)
      CPM + CTR → CPC                CVR + AOV → RPU
      "coste de traer 1 clic"        "ingreso por cada clic que llega"
            └──────────────┬──────────────┘
                  Front-end ROAS = RPU ÷ CPC
```

Devuelve: el árbol relleno con los números de la marca, el **veredicto ads-vs-web**, el **front-end ROAS**, el **Front-End Profit** y su relación con el **profit a 90 días (CLV)**, y **dónde está el apalancamiento** (casi siempre RPU). No es un unit-economics completo (eso es `mlo-ecom-financials-2026`); es el triage.

## Cuándo usarla (ES + EN triggers)
- **ES:** "diagnóstico de KPIs de [marca]", "árbol de ROAS", "descompón el ROAS", "por qué el ROAS engaña", "¿el cuello es ads o web?", "¿es problema de creativo o de la web?", "RPU / EPC de [marca]", "front vs back-end", "front-end ROAS", "cuánto gano por usuario", "si subo el CVR/AOV cuánto sube el ROAS", "el ROAS es 2 pero no gano", "diagnostícame los números de [marca]".
- **EN:** "KPI tree diagnosis", "decompose ROAS", "why ROAS is misleading", "is the bottleneck creative or the site", "RPU / EPC for [brand]", "front-end vs 90-day profit", "where's the leverage".
- **NO usar para (deriva a):** unit economics profundos, break-even ROAS, MER/aMER/nCAC, LTGP:CAC, P&L, caja → `mlo-ecom-financials-2026`. Deck de inversión / cuánto invertir / profit frontier → `mlo-scale-report`. Finanzas de dirección → `mlo-cfo-advisor`. Diseñar y priorizar tests on-site para subir CVR/AOV → `mlo-cro-2026`. Volumen/hit-rate/forecast creativo → `mlo-estratega-creativo`.

## Inputs que necesita
1. **Ad performance:** CPM y CTR (o directamente el CPC), gasto. Fuente: Meta / Atria.
2. **Website performance:** CVR (sesiones→pedidos) y AOV. Fuente: Shopify / Triple Whale.
3. **Rentabilidad ligera:** margen de contribución (COGS%; si no lo tienes, pídelo o usa el del Brand Brain), y CPA. Fuente: Shopify + Meta.
4. **Back-end (opcional pero clave):** CLV a 90 días (o LTV de ventana definida). Fuente: Triple Whale / Shopify.
5. **Idioma** (ES/EN) y moneda de la marca. Respeta las convenciones MLO (coma decimal en ES, moneda nativa: MXN Bala, COP V-UP/i-Energy, GBP Bridge/MUTO, etc.).

Si falta un dato, **pídelo o márcalo como supuesto explícito** — nunca inventes un CVR o un margen.

## Método (el árbol, paso a paso)
1. **AD PERFORMANCE → CPC.** `CPC = CPM ÷ 1000 ÷ CTR`. Es el coste de traer UN clic a la web. El CPC tiene **suelo** (hay un mínimo de mercado que la subasta te cobra por atención): por eso NO es la palanca principal.
2. **WEBSITE PERFORMANCE → RPU.** `RPU (Revenue Per User) = CVR × AOV`. Es el ingreso que genera cada clic que llega. El RPU tiene **techo mucho más alto** que el ahorro posible en CPC → **es la palanca reina**. (RPU ≈ RPV/Revenue Per Visitor en el vocabulario de `mlo-ecom-financials-2026`.)
3. **FRONT-END ROAS = RPU ÷ CPC.** El ROAS del primer pedido, reconstruido desde el árbol. Debe cuadrar con el ROAS que ves en Meta/TW; si no cuadra, hay un problema de atribución o de ventana — señálalo (ver `feedback_double_check_always`).
4. **FRONT-END PROFIT = (AOV × margen) − CPA.** ¿Ganas dinero en la PRIMERA compra? Si es positivo, escalas con caja propia; si es ~0 o negativo, sólo escalas si el back-end (CLV) lo justifica.
5. **PROFIT A 90 DÍAS = (CLV_90d × margen) − CPA.** El de verdad. Un front-end en break-even es **sano** si el 90D profit es fuerte (el negocio gana en la recompra). Aquí es donde el ROAS a secas miente más.
6. **VEREDICTO ads-vs-web.** Compara las dos mitades contra los benchmarks de la marca (no de la industria — regla MLO: benchmark contra tu propia cuenta):
   - **CPC alto / CTR bajo / CPM alto** → cuello en **Ad Performance** = creativo + segmentación. Deriva a `mlo-estratega-creativo`, `hooks-expert`, `static-ads-expert`, `mlo-media-buying-2026`.
   - **CVR bajo / AOV bajo** → cuello en **Website Performance** = landing/PDP + oferta/bundle. Deriva a `mlo-cro-2026`, `mlo-page-cooker`, `mlo-offer-simulator`.
7. **CUANTIFICA EL APALANCAMIENTO.** Muestra qué pasa si tocas cada palanca (siempre gana la web). Usa el escenario canónico como plantilla y sustituye por los números de la marca.
8. **SIGUIENTE PASO.** Una acción concreta por mitad + a qué skill/SOP pasa el balón. No entregues el árbol sin el "y ahora qué".

## Escenario canónico (memorízalo — es el patrón)
| Nivel | Fórmula | Valor |
|---|---|---|
| CPM | dato | $30 |
| CTR | dato | 2% |
| **CPC** | CPM ÷ 1000 ÷ CTR | **$1,50** |
| CVR | dato | 5% |
| AOV | dato | $60 |
| **RPU** | CVR × AOV | **$3,00** |
| **Front-end ROAS** | RPU ÷ CPC = 3 ÷ 1,50 | **2,0x** |
| Margen (COGS) | dato | 80% |
| CPA | dato | $30 |
| **Front-End Profit** | AOV×margen − CPA = 48 − 30 | **$18** |
| CLV 90d | dato | $150 |
| **90D Profit** | CLV×margen − CPA = 120 − 30 | **$90** |

**La lección del apalancamiento** (misma inversión en ads, tocando SÓLO la web): subir CVR 5%→6,5% y AOV $60→$80 lleva **RPU $3 → $5,20** y **ROAS 2,0x → 3,47x**. El CPC ni se movió. Por eso el foco es Website Performance / RPU. (El detalle numérico y el birds-eye mensual están en `reference/kpi-tree.md`.)

## Reglas y estándares (no negociables MLO)
- **RPU es la métrica reina.** CPC tiene suelo, RPU tiene techo → el apalancamiento está en la web. Dilo siempre en el veredicto.
- **El ROAS a secas engaña.** Nunca entregues un ROAS sin abrir el árbol; el mismo ROAS esconde enfermedades opuestas.
- **Profit/caja > ROAS vanidoso.** Un front-end en break-even es OK si el 90D profit lo sostiene; un ROAS "bonito" que no deja beneficio no es una victoria.
- **Front-end vs back-end explícito.** Siempre separa "¿gano en la 1ª compra?" de "¿gano a 90 días?". Decide el techo de CPA con el back-end, no con el front.
- **Benchmark contra la propia cuenta**, no contra la industria.
- **Double-check lo que RENDERIZA.** Que el front-end ROAS reconstruido cuadre con Meta/TW; si no, es atribución/ventana, no matemática (`feedback_double_check_always`, `feedback_ncpa_hitrate_methodology`).
- **Defiere la profundidad.** Break-even ROAS, LTGP:CAC, MER/nCAC, P&L y caja → `mlo-ecom-financials-2026`. Esta skill hace el triage, no el estado financiero.
- **ES/EN + moneda nativa** de la marca, con las convenciones de formato MLO.

## Output (forma exacta)
```
DIAGNÓSTICO RPU — [Marca] · [periodo] · [fuente: Meta+Shopify+TW]

ÁRBOL
  Ad Performance:      CPM [x] · CTR [x]% → CPC [x]
  Website Performance: CVR [x]% · AOV [x] → RPU [x]
  Front-end ROAS = RPU ÷ CPC = [x]x   (Meta/TW dice [x]x → [cuadra / desfase por atribución])

RENTABILIDAD
  Front-End Profit = AOV×margen − CPA = [x]   → [gano / break-even / pierdo] en la 1ª compra
  90D Profit       = CLV×margen − CPA = [x]   → [el negocio gana en la recompra: sí/no]

VEREDICTO
  Cuello de botella: [AD PERFORMANCE (creativo/segmentación) | WEBSITE PERFORMANCE (LP/oferta)]
  Por qué: [la mitad que está bajo su benchmark propio]

APALANCAMIENTO (misma inversión en ads)
  Si [palanca web]: RPU [x]→[y], ROAS [x]→[y]x   ← mayor palanca
  Si [palanca ad]:  CPC [x]→[y], ROAS [x]→[y]x

SIGUIENTE PASO
  → [acción concreta] · pasa a [skill/SOP]
```

## Guardrails
- No inventes CVR, margen, CPA ni CLV — pídelos o márcalos como supuesto. Sin margen fiable, el Front-End Profit es orientativo, dilo.
- No te quedes en el número: todo diagnóstico termina en veredicto ads-vs-web + siguiente paso + a qué skill pasa el balón.
- No dupliques `mlo-ecom-financials-2026`: si la pregunta es "¿cuánto puedo pagar por cliente / break-even ROAS / LTGP:CAC / P&L / caja", deriva ahí.
- No conviertas esto en un scale report ni en un deck: es diagnóstico rápido; si piden deck/inversión, `mlo-scale-report`.
- Front-end ROAS reconstruido que no cuadra con la plataforma = problema de atribución/ventana, no de fórmula — investígalo, no lo maquilles.

## References
- **Árbol completo + worksheet + birds-eye:** `reference/kpi-tree.md` (definiciones nivel a nivel, tabla de apalancamiento extendida, eCom Variables mensual, "clona el KPI Sheet", Definition of Done, checklist de veredicto).
- **Fuente del curso:** Accelerated Advisory (agencia CRO detrás de AG1, Huel, Hormozi, The Oodie…), módulos `01-intro-onboarding` (1.3 KPIs/RPU), `04-behaviour-data` (4.7 KPI tree) y `18-analysis-iteration` (eCom_Variables, RPU = AOV×CVR como métrica conectora site→revenue), en `~/Documents/CODEX/accelerated-advisory/modules/`.
- **Skills hermanas (referenciar, no forkar):** `mlo-ecom-financials-2026` (unit economics profundos — su "101" es este árbol; RPU≈RPV), `mlo-scale-report` (deck de inversión), `mlo-cfo-advisor` (finanzas dirección), `mlo-cro-2026` (testing on-site que sube CVR/AOV/RPU). Palanca ad-side: `mlo-estratega-creativo`, `hooks-expert`, `static-ads-expert`, `mlo-media-buying-2026`. Palanca web-side: `mlo-page-cooker`, `mlo-offer-simulator`.
