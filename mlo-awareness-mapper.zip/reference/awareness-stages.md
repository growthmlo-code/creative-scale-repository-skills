# Awareness Stages — base de conocimiento (Awareness Mapper)

Fuente: Eugene Schwartz, *Breakthrough Advertising* (1966), tal como se enseña en Accelerated Advisory Módulo 02 (Marketing Fundamentals) y Módulo 16 (Meta Ad Account & Scaling / DRA Framework). Este archivo es el cerebro del skill `mlo-awareness-mapper`.

Principio rector: **el WORDING del headline coloca el asset en el stage — no el layout, no el formato, no la plantilla.** Todo lo de abajo sirve para leer las palabras y colocarlas.

---

## 1. Los 5 Market Awareness Stages (tabla profunda)

Los stages van de 5 (el más grande, difícil y caro de mover) a 1 (el más fácil, la "free money zone"). En numeración de embudo: 5 Unaware es lo más frío / TOF; 1 Most Aware es lo más caliente / BOF.

| # | Stage | Mentalidad del lector | Objetivo del mensaje | Formato de PÁGINA (M02) | Foco del ANUNCIO (M16) | CTA típico (M16) | Etapa embudo |
|---|-------|-----------------------|----------------------|-------------------------|------------------------|------------------|--------------|
| 5 | **Unaware** | "No tengo ningún problema" | Plantar la semilla del problema; hook emocional; interrumpir + curiosidad; **sin producto, sin features** | Advertorial nativo, ad-historia, magazine | Interrumpir y crear curiosidad; nada de producto | "Watch now", "This surprised me", "Descubre por qué" | TOF |
| 4 | **Problem Aware** | "Tengo un problema, no sé cómo resolverlo" | Validar y dramatizar el problema + sus consecuencias; mostrar que existen soluciones (aún **no** la tuya) | Problem Recognition Page, advertorial, VSL. (Listicles NO aquí) | Nombrar el dolor y sus consecuencias | "Discover the cause", "Descubre la causa" | TOF |
| 3 | **Solution Aware** | "¿Qué solución/categoría es la mejor?" | Posicionar tu categoría/mecanismo como el mejor; "play dirty" (comparar) | Listicle ("5 Best Ways to…"), comparison advertorial/page, comparison VSL, quiz | Cómo funciona / el mecanismo; explainer o mini-VSL | "How it works", "Cómo funciona" | MOF |
| 2 | **Product Aware** | "Conozco tu producto, ¿por qué el tuyo?" | Confianza, superioridad, social proof / autoridad; matar objeciones | PDP, sales page, listicle de producto, página "7 Myths" (objeciones) | Confianza y prueba: reviews, before/after, expertos | "See the proof", "Mira las pruebas" | BOF |
| 1 | **Most Aware** ("Free Money Zone") | "Lo quiero, empújame" | Conversión sin fricción + oferta; urgencia/exclusividad | Cualquier página con CTA claro, checkout directo, descuento/bundle; email/retención/remarketing | Urgencia y exclusividad; **el ROAS más alto** | "Buy now", "Limited", "Cómpralo ya" | BOF |

Runway: cuanto **menos consciente** el lector, más tiene el asset que **ganarse el problema antes de enseñar el producto**. Cuanto **más consciente**, más rápido va a la oferta.

Ejemplo canónico Unaware (Cocunat): Taboola "Why Your Expensive Anti-Aging Cream Isn't Working" → VSL. Interrumpe sin nombrar producto.

---

## 2. Palabras-señal para clasificar por WORDING

Lee el headline verbatim y busca qué está haciendo con las palabras. Esto es lo que rellena la columna "palabras que deciden el stage".

- **Unaware** → el headline NO nombra ni el problema ni la categoría; abre con historia, identidad, curiosidad o una verdad tangencial. Señales: "Why your … isn't working", "The real reason…", "Nadie te contó que…", preguntas de estilo de vida, ninguna mención de producto/dolor.
- **Problem Aware** → el headline **nombra el problema/síntoma/consecuencia** pero no una solución concreta. Señales: "¿Te levantas cansado aunque duermas 8h?", "Si te pasa X…", dolor + consecuencia, "por qué ocurre", "la causa de…". Sin categoría de solución todavía.
- **Solution Aware** → el headline compara soluciones/categorías o nombra un **mecanismo/tipo de solución**. Señales: "Best ways to…", "X vs Y", "el método que…", "por qué [categoría] funciona mejor que [otra]", "cómo funciona", listicles de opciones.
- **Product Aware** → el headline nombra **tu producto/marca** y argumenta por qué el tuyo. Señales: nombre de marca/producto, "por qué [Marca]", reviews/rating, "4.9★", before/after, "recomendado por", "7 mitos sobre [producto]".
- **Most Aware** → el headline asume que ya lo quiere y **empuja con oferta/urgencia**. Señales: precio, descuento, "-30%", "hoy", "últimas unidades", "bundle", código, "compra ahora", envío gratis.

Regla de desempate: si un headline toca dos stages, gana el **más frío** de los dos que las palabras justifiquen (porque servir un mensaje demasiado caliente a un lector más frío es el failure mode). Anótalo como baja confianza y pásalo por el árbol de decisión.

---

## 3. Heurística fuente-de-tráfico → stage (validación, no decisión)

Sirve para **validar** la clasificación por wording y para detectar mismatch. Nunca sobrescribe al wording.

| Fuente de tráfico | Stage esperado |
|-------------------|----------------|
| Brand / direct search (busca la marca) | Product / Most Aware |
| Non-brand search (busca la categoría o el problema) | Solution / Problem Aware |
| Feeds de interrupción: Meta / Instagram / TikTok / Taboola / Outbrain | Unaware → Problem Aware |

Si el wording dice "Most Aware" pero la fuente es un feed de Meta frío → **mismatch**: probable oferta caliente disparada a público frío. Márcalo.

---

## 4. Árbol de decisión (para headlines ambiguos)

Recorrer en orden; parar en el primer "sí".

1. ¿El lector conoce **tu producto**? → **sí:** Product o Most Aware.
2. (si no) ¿Conoce un **producto similar / la categoría de producto**? → **sí:** Product Aware.
3. (si no) ¿Sabe que **existen soluciones** para su problema? → **sí:** Solution Aware.
4. (si no) ¿Es **consciente del problema**? → **sí:** Problem Aware.
5. (si no) → **Unaware.**

---

## 5. Awareness Map worksheet

Una fila por asset (cada landing/presell/advertorial/PDP + cada uno de los top-5 ads por gasto).

| Columna | Qué va |
|---------|--------|
| **Asset** | Qué es y dónde vive (p.ej. "Landing sleep-quiz /pages/quiz", "Ad #1 spend €4.2k → PDP") |
| **Headline as written** | El headline VERBATIM, entre comillas. Copia literal; no parafrasear |
| **Stage** | Unaware / Problem / Solution / Product / Most — decidido por el wording |
| **Palabras que deciden el stage** | Las palabras concretas del headline que lo colocan ahí |
| **Gap** | "—" si encaja; "mismatch: escrito [stage] pero fuente/lector [stage]"; u otra nota |

Después de la tabla:
- **Conteo de cobertura por stage** (cuántos assets caen en cada uno de los 5).
- **Stages vacíos** = **gaps del funnel roadmap**. Nómbralos y di qué implica cada hueco (p.ej. "vacío en Problem Aware → el frío de Meta llega directo a PDP product-aware = failure mode").
- **Mismatches** listados como fixes priorizables.

### Definition of Done (QA gate)
El mapa está terminado cuando:
1. **Todos** los assets pedidos (páginas + top-5 ads) tienen fila, con headline verbatim.
2. Cada fila tiene stage **justificado por palabras concretas** (no "porque es un advertorial").
3. Está el conteo por stage y **marcados los stages vacíos** como gaps.
4. Están señalados los **mismatches** (wording vs fuente/lector).
5. Hay un **par de headlines** (problem-aware + solution-aware) para el stage principal, en voz de marca.
6. Hay **plan de test en batches** + **formato/CTA recomendado** por gap, con el skill al que se deriva cada fix.

---

## 6. Failure mode

**El error #1: servir copy de un stage a la mentalidad de otro** — típicamente copy product-aware a un lector problem-aware (le hablas de tu producto cuando ni sabe que hay soluciones). También: oferta Most-Aware a frío Unaware; bare claim a un mercado saturado. Cada mismatch detectado es un fix.

---

## 7. Método de test en batches (M02 + M16)

Cómo se prueba qué stage mueve la cuenta, y cómo se financia:

1. **3-5 anuncios, UNA variante por stage** (mismo producto/oferta, distinto mensaje según stage).
2. **Race** por CTR / CPA / CVR con benchmarks predefinidos antes de gastar (kill / iterate / scale).
3. Presupuesto de test disciplinado: **2×–2,5× AOV por creativo, correr ~7 días** (M16). Los winners no llegan rápido; ganar = apilar aprendizajes.
4. **Presupuesto a la Winning Stage**; tests pequeños en el resto. En 2026 con targeting broad por defecto, **la awareness stage es el filtro real** — el algoritmo mide engagement, tú matcheas mensaje ↔ mentalidad.
5. Escalar la Winning Stage por capas (ver `mlo-sistema-creativo-2026` / M16 Layers 1-3: variaciones → ángulo → formato).

---

## 8. Matriz stage → formato (referencia rápida para tapar gaps)

Cuando un stage está vacío, este es el formato + CTA que se recomienda para taparlo, y a qué skill se deriva la construcción:

| Stage vacío | Formato a crear | CTA | Derivar a |
|-------------|-----------------|-----|-----------|
| Unaware | Advertorial nativo / ad-historia / magazine | "Watch now" / curiosidad | `unaware-ads-expert`, `mlo-page-cooker` |
| Problem Aware | Problem Recognition Page / advertorial / VSL | "Descubre la causa" | `angle-generator`, `mlo-page-cooker` |
| Solution Aware | Listicle / comparison page / quiz | "Cómo funciona" | `mlo-page-cooker`, `angle-generator` |
| Product Aware | PDP / sales page / "7 Myths" page | "Mira las pruebas" | `mlo-page-cooker` |
| Most Aware | Página con oferta/checkout directo, bundle, email/remarketing | "Cómpralo ya / -X%" | `mlo-page-cooker`, email/retención |

---

## 9. Relación con otros skills MLO

- **`psychological-coverage`** — GENERA la cobertura psicológica (Awareness Map + matriz desde cero). Este skill **audita** los assets que ya existen. Si el usuario quiere crear cobertura de cero, derivar allí.
- **`unaware-ads-expert` / `advertorial-strategist` / `mlo-listicle-advertorial-brief`** — construyen el creativo/página del stage frío una vez detectado el gap.
- **`angle-generator` / `hooks-expert` / `creative-strategist` / `mlo-sistema-creativo-2026`** — generan ángulos/hooks/volumen para llenar los gaps y escalar la Winning Stage.
- **`mlo-page-cooker` / `mlo-cro-2026`** — construyen y publican la página que tapa el gap (preset/presell + EPC).
- **`mlo-auditoria-ecommerce`** — usa el Awareness Map como uno de sus pilares al auditar prospectos externos.
