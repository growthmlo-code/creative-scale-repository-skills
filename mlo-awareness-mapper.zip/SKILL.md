---
name: mlo-awareness-mapper
description: >
  El AUDITOR de cobertura de awareness de MLO Growth. Coge las páginas vivas de una marca (landings, presells,
  advertoriales, PDP, home) + sus top-5 anuncios por gasto (Meta API + Shopify) y CLASIFICA cada asset en uno de los
  5 Market Awareness Stages de Schwartz — Unaware → Problem Aware → Solution Aware → Product Aware → Most Aware —
  decidiendo el stage POR EL WORDING DEL HEADLINE (no por el layout ni el formato). Marca los stages VACÍOS (= gaps del
  funnel roadmap), aplica la heurística fuente-de-tráfico→stage y el árbol de decisión, y devuelve un par de headlines
  (problem-aware + solution-aware) para el stage principal, más el método de test en batches (3-5 ads, una por stage,
  presupuesto a la Winning Stage). ALWAYS use this skill (ES/EN) cuando Marcel o el equipo pidan: "mapea el awareness
  de [marca]", "en qué stage está esta página / este ad", "cobertura de awareness de [marca]", "qué formato para
  cold / frío / público frío", "awareness map de [marca]", "clasifica estos ads por awareness", "en qué stage está
  esta landing", "auditoría de awareness", "tengo huecos en el funnel", "map the awareness of [brand]", "which stage
  is this landing / ad", "classify these ads by awareness", "awareness coverage for [brand]", "what format for cold
  traffic", "which awareness stage is this page". Trigger también con peticiones parciales o casuales sobre en qué
  stage de consciencia cae una página o un anuncio, qué stages le faltan a una marca, o qué formato toca para frío.
  COMPLEMENTA a psychological-coverage (esa GENERA la cobertura psicológica; esta AUDITA los assets que ya existen),
  unaware-ads-expert, angle-generator, mlo-sistema-creativo-2026 y mlo-page-cooker. Funciona para cualquier marca MLO
  (ZZEN, 8hours, Bala di Gala, Moncho Moreno, Alma, Chic&Love, HobbitAlf, etc.).
---
# Awareness Mapper

## Qué hace
Coge los **assets vivos** de una marca (páginas + top-5 anuncios por gasto) y los **clasifica en los 5 Market Awareness Stages de Schwartz** *por el wording del headline*, no por el formato. Devuelve un **Awareness Map** (una fila por asset), marca los **stages vacíos** como gaps del funnel roadmap, y genera un **par de headlines (problem-aware + solution-aware)** para el stage principal. Es el **auditor** del sistema de awareness: donde `psychological-coverage` *genera* cobertura desde cero, este skill *audita lo que la marca ya tiene corriendo* y te dice qué falta.

Se apoya en el curso Accelerated Advisory: la tabla de 5 stages + Awareness Map worksheet (Módulo 02) y el foco creativo + CTA por stage para media buying (Módulo 16).

## Cuándo usarlo (ES + EN)
- **ES:** "mapea el awareness de [marca]", "en qué stage está esta página / este ad", "cobertura de awareness de [marca]", "clasifica estos ads por awareness", "en qué stage está esta landing / advertorial / PDP", "auditoría de awareness", "qué stages le faltan a [marca]", "tengo huecos en el funnel", "qué formato uso para frío / cold / público frío", "qué headline para el stage principal".
- **EN:** "map the awareness of [brand]", "which stage is this landing / ad", "classify these ads by awareness", "awareness coverage for [brand]", "which awareness stage is this page", "what format for cold traffic", "awareness gaps for [brand]".
- **NO usar para:** *generar* cobertura psicológica desde cero → `psychological-coverage`; escribir el concepto **unaware** en profundidad → `unaware-ads-expert`; generar **ángulos** → `angle-generator`; construir/publicar la **página** que tape un gap → `mlo-page-cooker`; el sistema creativo de volumen/hit-rate → `mlo-sistema-creativo-2026`. Este skill **audita y clasifica lo existente**; los demás **crean**.

## Inputs necesarios
1. **Marca / dominio** (y, si es marca MLO, su Brand Brain para VoC y tono).
2. **Páginas vivas** a auditar: home, PDP(s), landings/presells, advertoriales, listicles, quiz. Si no te las dan, saca las principales del sitio (menú + páginas enlazadas desde los ads).
3. **Top-5 anuncios por gasto** — vía Meta API (últimos 30 días, ordenar por spend). Necesitas el **primary text + headline tal como está escrito**, y a qué página envía cada uno.
4. **Shopify** — para confirmar a qué página aterriza cada ad y qué es (PDP vs landing vs colección).
5. Opcional: ventana temporal, idioma ES/EN, si quieres solo páginas o solo ads.

Si falta el acceso a Meta/Shopify, dilo y trabaja con lo que se pueda leer del sitio + biblioteca de anuncios pública; no inventes headlines.

## Método (numerado)
1. **Recoge los assets.** Páginas vivas + top-5 ads por gasto (Meta API, 30d, orden por spend). Para cada uno captura el **headline TAL COMO ESTÁ ESCRITO** (verbatim) y la URL de destino. Confirma el destino con Shopify.
2. **Clasifica CADA asset por el WORDING del headline**, no por el formato ni el layout. Esta es la regla dura: *el wording del headline coloca el asset en el stage.* Un advertorial puede estar escrito product-aware; una PDP puede abrir problem-aware. Lee las palabras, no la plantilla. (Tabla + palabras-señal por stage en la referencia.)
3. **Cruza con la heurística fuente→stage** para validar (no para decidir): brand/direct search = product/most aware; non-brand search = solution/problem; feeds Meta/TikTok/Taboola/Outbrain = unaware→problem. Si el wording y la fuente chocan, gana el wording pero anótalo como posible **mismatch** (failure mode).
4. **Aplica el árbol de decisión** cuando un headline sea ambiguo (ver §Árbol de decisión).
5. **Rellena el Awareness Map worksheet** — una fila por asset con las columnas: `Asset | Headline as written | Stage | palabras que deciden el stage | Gap`.
6. **Marca los stages VACÍOS.** Cada stage sin ningún asset = **gap del funnel roadmap**. Nombra el gap ("no hay nada para Problem Aware → el frío llega directo a oferta"). Esto es el entregable clave de la auditoría.
7. **Detecta mismatches** (failure mode canónico): copy product-aware servido a un lector problem-aware, oferta Most-Aware disparada a frío Unaware, etc. Cada mismatch es un fix priorizable.
8. **Genera el par de headlines para el stage principal** — un headline **problem-aware** + uno **solution-aware** listos para testear, en la voz de la marca (VoC del Brand Brain; no traducir literal del inglés).
9. **Prescribe el test en batches** — 3-5 ads, **una variante por stage**, race por CTR/CPA/CVR, presupuesto a la **Winning Stage**, tests pequeños en el resto (§Batch-test).
10. **Recomienda el formato + CTA por stage** para tapar cada gap (matriz stage→formato de M02 + foco creativo/CTA de M16), y pasa el fix al skill que lo construye (`mlo-page-cooker` para páginas, `unaware-ads-expert`/`angle-generator` para creativo).

## Reglas y estándares (no negociables MLO)
- **El WORDING del headline decide el stage. El formato NO.** Nunca clasifiques "es un advertorial → problem aware". Lee las palabras.
- **Stage vacío = gap del funnel.** El valor del mapa está en los huecos, no en las casillas llenas.
- **La fuente de tráfico valida, no decide.** Úsala para detectar mismatch, no para sobrescribir el wording.
- **Failure mode a cazar siempre:** mensaje de un stage servido a la mentalidad de otro (product-aware para lector problem-aware).
- **Awareness pone el runway; cuanto menos consciente, más tiene que ganarse el problema antes del producto.** Most-Aware = free money zone (empujar + oferta); Unaware = plantar el problema sin producto.
- **Verbatim o nada.** El headline "as written" se copia literal; si no puedes leerlo, no lo clasifiques ni lo inventes.
- **Este skill audita; no reescribe páginas ni lanza ads.** Entrega el mapa, los gaps y el par de headlines; el fix va al skill que corresponda.
- **ES/EN en la voz de la marca**, convenciones MLO (coma decimal, % sin símbolo si aplica), sin traducción literal.

## Output (forma exacta)
```
AWARENESS MAP — [Marca] · [ventana] · fuente: [Meta API + Shopify + sitio]

| Asset | Headline as written | Stage | Palabras que deciden el stage | Gap |
|-------|---------------------|-------|-------------------------------|-----|
| [landing / PDP / ad #1 ...] | "[verbatim]" | [Unaware/Problem/Solution/Product/Most] | [palabras-señal] | [—/mismatch/nota] |

COBERTURA POR STAGE:
Unaware:  [n assets]   Problem: [n]   Solution: [n]   Product: [n]   Most: [n]
STAGES VACÍOS (= gaps del funnel roadmap): [lista + qué implica cada hueco]
MISMATCHES: [asset → stage escrito vs stage del lector/fuente]

STAGE PRINCIPAL (donde concentra el gasto/tráfico): [stage]
Par de headlines para testear:
 · Problem-aware:  "[headline]"
 · Solution-aware: "[headline]"

PLAN DE TEST EN BATCHES: [3-5 ads, una por stage; métrica; a dónde va el budget]
FORMATO + CTA RECOMENDADO PARA TAPAR CADA GAP: [stage → formato → CTA]  (pasar a: [skill])
```

## Guardrails
- No clasifiques por formato ni por "lo que parece": el wording manda. Si el headline es ambiguo, usa el árbol de decisión y anótalo como baja confianza.
- No inventes headlines ni destinos: si no puedes leer el ad/página (sin acceso Meta/Shopify), dilo y limita el mapa a lo verificable.
- No confundas "casilla llena" con "casilla buena": un asset mal escrito para su stage sigue siendo un gap (mismatch), márcalo.
- No reescribas la página ni lances el ad desde aquí: entrega mapa + gaps + par de headlines y deriva el fix (`mlo-page-cooker`, `unaware-ads-expert`, `angle-generator`).
- Complementa, no dupliques, `psychological-coverage`: si el usuario quiere *generar* cobertura desde cero, deriva; este skill parte de assets **existentes**.
- ES/EN en voz de marca, sin traducción literal; convenciones numéricas MLO.

## References
- **Base de conocimiento completa:** `reference/awareness-stages.md` — tabla profunda de los 5 stages (mentalidad → objetivo → formato de página/ad → foco creativo → CTA), palabras-señal por stage para clasificar por wording, heurística fuente→stage, árbol de decisión, Awareness Map worksheet + Definition of Done, y el método de test en batches.
- **Módulos del curso (fuente):** `~/Documents/CODEX/accelerated-advisory/modules/02-marketing-fundamentals.md` (5 stages Schwartz, Awareness Map worksheet, matriz stage→formato, heurística por fuente, decision tree, failure mode) y `16-meta-ad-account-scaling.md` (foco creativo + CTA por stage para media buying, awareness coverage como una de las 4 áreas de auditoría, test en batches → escalar la Winning Stage).
- **Relación en la suite:** COMPLEMENTA `psychological-coverage` (genera cobertura ↔ este audita lo existente), `unaware-ads-expert` (concepto unaware/frío en profundidad), `angle-generator` (ángulos para tapar gaps), `mlo-sistema-creativo-2026` (volumen/hit-rate/cobertura), `mlo-page-cooker` (construye la página que tapa el gap). No los bifurca: entrega el diagnóstico y deriva el fix.
