# Master Offer Doc — Cold Friendly Offer Reference (Carl Weische / Accelerated)

Deep knowledge base for `mlo-cold-friendly-offer`. Grounded in the Accelerated Advisory course
(`~/Documents/CODEX/accelerated-advisory/modules/07-cold-friendly-offer.md` and `10-funnel-building.md`).
This is the AUTHORING brain. For SCORING/simulation use `mlo-offer-simulator`; for unit economics use `mlo-ecom-financials-2026`.

---

## 0. What a Cold Friendly Offer is (and why it's the whole game)

A **Cold Friendly Offer** is an offer engineered to stay **profitable on the FRONT END** — the first sale to **cold, unaware traffic** — so you can pour spend into paid without leaning on warm/returning audiences. The offer is **make-or-break**: it is the layer that makes creative scalable and profitable in cold. Elite operators attack the **largest and hardest segment (unaware)**, which has the biggest TAM but demands long-form persuasion (20-min VSLs, advertorials). Profitable at >$100k/day is the ceiling this framework targets.

The core problem it solves: **copycats, saturation, commoditization.** The fix is to become a **"category of one"** — an artificial blue ocean created by **upgrading the message**, not the product (only ~1% of brands have a truly unique product; the other 99% differentiate by HOW they market).

### The irresistible offer = 5 conditions
1. **Understand the prospect** deeply (VoC, pains, desires).
2. **High perceived value** (5–10× the price → feels like a steal).
3. **Trust / certainty** (proof + guarantee).
4. **High gross margin** (so you can spend aggressively in cold).
5. **No-brainer at zero risk.**

### Understanding the prospect = 5 steps
Pains → **maximize the dominant pain** (create urgency) → present the solution (easy + fast) → build perceived value → guarantee.

**Cold vs warm:** prioritize the COLD offer (that's what scales paid). Warm/returning gets its own treatment later. Rule of thumb for perceived value: **5–10× the price.**

**Research = data, not brainstorm.** Amazon/store reviews, surveys ("what else do you buy?" → bundle → raise AOV → strip complexity), Reddit. The offer is discovered in customer language, never invented.

**Product ≠ offer.** Wildo sold a razor; the offer was "5 years without plastic waste" (razor + stand + 100 blades). Vessi sold shoes; the offer was "second-skin waterproof." Sell the outcome, packaged.

---

## 1. The A–E Master Offer Doc framework

The canonical structure. Fill every block for the brand.

### A. Mass Market Desires (pick ≥1)
Hard-wired human drivers. Anchor the offer to at least one:
- **Reproduction / attractiveness** (pass on DNA — the deepest driver).
- **Status.**
- **Social belonging.**
- **Safety / health** (avoid pain, avoid dying — especially dying *alone*).

Two "core human drivers" the flagship case leans on: **reproduce** (pass on DNA) + **fear of dying (alone)**. Everything in the offer should ladder up to the chosen desire(s).

### B. Perceived Value (value UP, never price DOWN)
Discounting **kills margin** — the margin that funds aggressive cold spend. So you **raise perceived value** instead:
- Be the **All-In-One** — solve MORE of the problem, be **unique**, be a **must-have not a nice-to-have**.
- Compete on **unique value, not price.**
- **Perceived value target: 5–10× price** (steal sensation).

**Resourcefulness > resources** — build value cheaply, two levers:
1. **Change the narrative** (reframe the same product into a bigger outcome).
2. **Bundle** (turn an isolated product into a **holistic system**). A bundle you *don't* actively sell still works as a **price anchor** that raises AOV.

**Bundle types:**
- **Complementary** (product + the things used with it).
- **More-of-same** (multi-packs, supply for N months).
- **Info products** (guide/method/course — near-zero COGS).
- **Community** (accountability → CLV).

The **digital product** (guide, method, app, community) is the secret weapon: **COGS ≈ 0** → it lifts AOV and margin without cost, and it's **non-copyable** (competitors can copy a SKU, not your method + community).

### C. Persuasion
Stack these; always include a strong guarantee:
- **Social proof** (reviews, UGC, numbers).
- **Authority** (experts, credentials, press).
- **Certainty / Guarantee** — the risk-reversal engine. Options: **100-day no-questions-asked**, **3-year**, **30-day try-before-buy**. This is what delivers "no-brainer at zero risk."
- **Scarcity** (limited stock/seats/cohort).
- **Urgency** (deadline, cohort start).
- **Exclusivity** (members-only, access).

### D. Opportunity Analysis
Find the edge that makes a "category of one":
- An **unsolved problem** in the market.
- A **superior business/offer structure** (e.g. challenge+community vs one-off SKU).
- A **new market / new avatar** (e.g. sell to the boyfriend/husband, not the user — Nomisk/Maia).
- An **untapped traffic source.**

### E. Market Sophistication (5 levels)
As sophistication **rises**, unit economics get worse and you must **market the SAME product differently**. The 5-level ladder (mirror of the funnel module):
1. **Plain claim.**
2. **Amplified claim** (+ number / timeline).
3. **+ New mechanism.**
4. **+ Benefits stacked.**
5. **+ Identification / authority / call-out.**

Never fire a bare claim into a soph-4/5 market. Testosterone/"max sophistication" categories have the worst unit economics — that's exactly where you upgrade the message (mechanism, identity) rather than shout louder.

---

## 2. Offer archetypes

Pick by pain + margin + catalog, not taste. Add a digital/community layer to any of them when possible.

| Archetype | What it is | Best when | AOV/CLV lever |
|---|---|---|---|
| **Bundle** | Core + complements (+ digital + community) sold as a system | You can package a holistic outcome; catalog supports it | Anchor pricing raises AOV; digital lifts margin |
| **30-Day Challenge** | Time-boxed program: product + method + accountability | Adherence/habit is the real problem; community fits | Community → recurring CLV; challenge cohort = urgency |
| **BOGO** | Buy-one-get-one (or gift) | Consumable, giftable, volume play | Raises units/order; good for more-of-same |

Reference cases by archetype: **Wildo** (bundle → "5 years without plastic"), **Shapewear** (BOGO), **Kinobody** (30-Day Challenge + community).

---

## 3. The Kinobody case (flagship — memorize the numbers)

**Situation:** Gregory O'Gallagher (Kinobody, 2.7M followers) sold **Kino Mojo** (a testosterone supplement) at **AOV $40**. It would **not scale on paid** — saturated, max-sophistication market, thin AOV, bad unit economics.

**The fix — the OFFER, not the ad:** bundle **Kino Mojo + Kino Nitro + a DIGITAL product (diet + training)** into the **"30-Day Mojo Mastery Challenge"**, plus a **Skool community** for accountability (→ CLV).
- **AOV $40 → $97.**
- **Subscription $69/mo** (the community/recurring layer).
- **Digital COGS ≈ 0** — this is what rescues the margin.
- **Price anchor:** $97 shown against $197.

**Results:**
- **NCPA −66%** (new-customer acquisition cost down two-thirds).
- **Spend −41%** (needed less spend for the same/greater result — front-end profit lets you scale efficiently).
- Scaled to **9.3× ROAS.**
- Net profit **+>$200k/month.**

**Why it worked:** the digital + community layer lifted AOV and margin at ~zero cost → the offer became **profitable on the first cold sale**, and the community extended CLV and made the offer **non-copyable**. This bundle+community model is the **template** for any supplement/fitness/beauty/health brand hitting a sophistication ceiling (QiHealth, Nurse is Love, Moncho, V-UP, i-Energy).

### Kinobody 5-step creative framework (the ad layer that feeds the offer)
1. **Angle testing** — test broad angles (testosterone / dating / fitness). **DATING won** — the "random" one, discovered in data.
2. **Double down** — deep research on the winner (Reddit r/datingadvice, YouTube/FB comments) → real hooks in customer language.
3. **Iterate** — one variation per pain / objection.
4. **VSL** — promise → proof → hero story → epiphany → call-out → shade other solutions → mechanism → pitch.
5. **Congruent LP.**

---

## 4. Native Static / Meta DRA doctrine — "the mechanism is the hero"

The image gets the click; the **primary text sells** (it's a sales letter). Technique order (for the ad that carries the offer):
ugly/authentic image (pattern interrupt "that's me") → problem stacking → **new mechanism** (Problem / Mechanism / Solution) → identity pain → open loop → reframe → emotion for attention + logic to justify → reveal the ingredient LATE → rule of three → create an enemy (old vs new) → future pacing → product only after ~80% education → risk reversal (90-day).

**Key lesson: the MECHANISM is the hero, not the product.** The offer's "new mechanism" (E-level 3) is what you dramatize.

---

## 5. Congruent landing-page brief (how the offer gets monetized)

Cold traffic doesn't fail to buy — it fails on **message leakage between ad and page** (the biggest leak). The page **"finishes the sentence the ad starts."**

- **Congruence = a conversion lever:** same problem / desire / language / emotion / awareness from the ad's first frame to the page's first scroll. Cold needs **continuity, not explanation.**
- **"Ads = market research in disguise."** Don't ask "what's the better page?" — ask "**which ad already does the work?**", rip that angle, and build a page that **expands the promise.**
- **Build pages from ANGLES, not products:** **1 page = 1 angle = 1 desire = 1 problem.** Dedicated pages, never generic PDPs.
- Headline = the ad's promise; sub = clarification; section 1 = emotional continuation of the ad; proof = reinforcement.
- **"Winning ads discover the message; congruent pages monetize it."**

### The 8-section LP spine (Kinobody / Cocunat)
1. **Hero + VSL** (the promise ATF).
2. **Value prop.**
3. **Success stories.**
4. **Offer breakdown** (the stack itemized with standalone values).
5. **Offer + CTA.**
6. **Testimonials.**
7. **Guarantee.**
8. **FAQ.**

Skimmer rules (Cocunat): repeat the **same benefit across multiple designs** for skimmers; **benefits over features**; before/afters, comparison with/without, multiple social-proof designs, countdown.

Hand the actual page build to `mlo-page-cooker` / `mlo-cro-2026`; hand the VSL to `mlo-vsl-writer`. This skill writes the **brief**.

---

## 6. More reference cases (A–E in the wild)

- **Nomisk / Maia** — sold to a **new avatar**: the boyfriend/husband ("6 reasons you need Maia for your girlfriend"). Opportunity = new market (D) + reproduction/status desire (A).
- **More Nutrition** — protein cream + **recipes** (info bundle) → All-In-One, value up (B).
- **AG1 Starter Kit** — bundle-as-anchor + authority + guarantee (B + C).
- **Maniko** — reframed narrative (B).
- **Cocunat "Curly Method"** — a **method** wrapped around products; 6–7 avatars → a $70 bundle LP; new mechanism (E-3) + benefits stacked (E-4).
- **Wildo** — razor + stand + 100 blades → "5 years without plastic" (product ≠ offer; bundle + narrative).
- **Vessi** — "second-skin waterproof"; travel narrative; UGC travel-photographer → congruent identical LP.
- **PetLab / Java Coffee / NuBrew** — advertorial/listicle presell → offer page with subscription + cross-sells + post-purchase upsells + community (funnel module).

---

## 7. Authoring checklist (run before shipping the offer)

- [ ] Profiling read; dominant pain identified and **maximized** (urgency); outcome named in customer's words.
- [ ] **≥1 Mass Market Desire (A)** chosen and every element ladders to it.
- [ ] Value built **UP** (bundle + narrative + digital/community), **no discount** as the lever.
- [ ] **Perceived value 5–10× price**; each stack item has a standalone value; **anchor** set.
- [ ] **Digital/community layer** added where possible (COGS ≈ 0 → front-end profit + CLV + non-copyable).
- [ ] Archetype (bundle / 30-day challenge / BOGO) chosen by pain + margin + catalog.
- [ ] **Persuasion (C)** stacked, incl. a real, honorable **guarantee** (100-day / 3-yr / try-before-buy).
- [ ] **Opportunity edge (D)** named (unsolved problem / better structure / new market / untapped traffic).
- [ ] **Sophistication (E)** diagnosed; claim type matched (claim → mechanism → identity); same product marketed for the level.
- [ ] **Front-end thesis** checked vs `mlo-ecom-financials-2026` (CM%, break-even ROAS = 1/CM%, target NCPA) → profits/breaks even on first cold sale.
- [ ] Numbers pressure-tested in `mlo-offer-simulator`.
- [ ] **Congruent LP brief** written from the winning **angle** (1 page = 1 angle), 8-section spine, congruence check passed.
- [ ] ES/EN in brand voice, MLO conventions, no literal translation. Proof/guarantees grounded, nothing fabricated.
