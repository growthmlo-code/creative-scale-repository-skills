# Funnel Architect — Knowledge Base

Fuente: Accelerated Advisory · M10 Funnel Building Mastery (Carl Weische) + M14 Landing & Product Pages. Todo lo de abajo está anclado al curso; los casos son literales del material.

---

## 1) La espina canónica (narrative-based funnel)

Solo ~1% de las marcas tiene un producto realmente único. El otro 99% se diferencia por **CÓMO marketea** — por la narrativa, no por el SKU. Por eso el funnel no es "una web con un botón": es un **storyline congruente** que lleva a un visitante frío por cambios de mente. Nunca se tira tráfico frío a un product page.

**La espina (memorízala):**

```
Prospecting ad (TOF, whitelisted, FOMO)
        │
        ▼
Presell  ── listicle O advertorial ──  (NUNCA directo al PDP)
        │
        ├── click ───────────────► Offer page  (palancas AOV/CLV)
        │                                │
        └── no click ──► Retargeting            ▼
                         testimonial       Checkout (cross-sells)
                         (objeción              │
                          muerta)               ▼
                                          Post-purchase
                                          (upsells one-time, comunidad)
```

**Leyenda del flowchart (color-coded, tal cual el curso M10.2):**
- 🔴 **Rojo = ad / creativo** (prospecting ad, retargeting testimonial).
- 🔵 **Azul = step / página** (presell, offer page, checkout, post-purchase).
- 🟤 **Marrón = email** (secuencias que empujan entre steps — p.ej. el email #2 con vídeo personalizado).
- 🟢 **Verde = palanca de AOV/CLV** (bundle, cross-sell, upsell, subscription, comunidad).
- 🟡 **Amarillo = punto de decisión** (el nodo click / no-click).

Cada step es un **cambio de mente**, no un tipo de página:
- **Prospecting ad (🔴):** rompe el scroll y planta la promesa del ángulo con FOMO. Whitelisted (corre desde el handle del creador para nativo).
- **Presell (🔵):** convierte la curiosidad del ad en una **razón para leer la oferta**. Listicle ("10 reasons…") o advertorial (editorial/PR-style). Educa al awareness que trae el ad. **Su ausencia = el ad va directo al PDP = funnel roto.**
- **Nodo decisión (🟡):** ¿hizo click hacia la oferta? Sí → offer page. No → no se pierde: entra en **retargeting testimonial**.
- **Retargeting testimonial (🔴):** al que no hizo click se le sirve **prueba social como matador de objeciones**. Rama obligatoria, no opcional.
- **Offer page (🔵 + 🟢):** vende + genera trust en UNA página, con **palancas de AOV/CLV** encima (bundle, pre-select, decoy).
- **Checkout (🔵 + 🟢):** **cross-sells** en el carrito (nudging).
- **Post-purchase (🔵 + 🟢):** **upsells one-time** tras la compra + **comunidad** (la palanca de CLV más infravalorada).

Hay **múltiples capas de AOV/CLV** a lo largo del funnel (bundle en la oferta, cross-sell en checkout, upsell + comunidad post-compra) — no una sola.

---

## 2) El motor: awareness × sophistication (Schwartz)

El funnel se diseña por el **estado mental** del tráfico de entrada. Dos ejes:

**Awareness (5 stages) — fija la LONGITUD DE PISTA** (cuánto educar antes de la oferta):
1. **Unaware** — no sabe que tiene el problema. Pista más larga. Mayor TAM → la élite abre aquí.
2. **Problem Aware** — siente el problema, no conoce soluciones.
3. **Solution Aware** — conoce tipos de solución, no tu producto.
4. **Product Aware** — conoce tu producto, no está convencido.
5. **Most Aware** — solo necesita la oferta/el empujón.

Regla: **cuanto menos aware, más presell** (advertorial largo, educar el problema antes de vender). Cuanto más aware, más rápido a la oferta. Nunca mandes una oferta Most-Aware a tráfico Unaware, ni al revés.

**Sophistication (5 stages) — fija el TIPO DE CLAIM** (cuántas veces el mercado ya oyó el claim):
1. **Claim directo** ("adelgaza").
2. **Claim ampliado** (+número/timeline: "adelgaza 5 kg en 30 días").
3. **+ Nuevo mecanismo** (cuando el claim ya no basta: el *cómo* diferencial).
4. **+ Beneficios apilados** (mecanismo elevado, stack de beneficios).
5. **+ Identificación / autoridad / call-out** (identidad: "para mujeres de 40+ que…").

Regla: mercado saturado (soph 4–5) → **mecanismo o identidad**, nunca claim pelado. La **élite abre el mercado unaware** porque el TAM es mayor y la competencia por el claim es menor.

> Para clasificar páginas y ads por stage en detalle y detectar stages vacíos, esta skill se apoya en `mlo-awareness-mapper` (cobertura de awareness por headline). Aquí se usa el eje solo para fijar pista y claim del funnel.

---

## 3) El Funnel Map worksheet (el deliverable core — SOP-gold M10.A)

Una fila por step. Columnas exactas:

| Columna | Qué va |
|---|---|
| **Step** | El step de la espina (prospecting ad, presell, offer page, checkout, post-purchase, + la rama retargeting). |
| **Live URL** | La URL real viva, o `does not exist` si el step no existe (eso ES el diagnóstico). |
| **What it does to the visitor** | El cambio de mente que provoca (no "es una landing" — sino "convierte la curiosidad del ad en razón para leer la oferta"). |
| **Roadmap block que lo owns** | La skill/block que construye o mantiene ese step. Si no lo puedes nombrar → `unowned`. |
| **Traffic lost here (source)** | Dónde sangra el tráfico, **con fuente y fecha**, o `sin dato`. |

**Ejemplo de fila (literal del curso):**
```
Presell | /pages/knee-relief-story | Turns ad curiosity into a reason to read the offer | ADVERTORIAL | 62% exit before 2nd screen · Clarity scroll map · 14 Aug
```

**Regla de oro:** *si no puedes nombrar el block que owns un step, ese step no está en el roadmap.* Un `unowned` es un hallazgo que hay que resolver, no un hueco que se ignora.

### Definition of Done (DoD)
- El **Funnel Map está en Slack** (pegado, legible de un vistazo).
- **Cada step lleva un roadmap block o `unowned`** — sin excepciones.
- **El cliente puede señalar el step exacto** que cambia su próximo block (i.e., el mapa es tan claro que el cliente entiende qué se construye después y por qué).
- (De M14.1, para el step de destino) el cliente **confirma por escrito qué UNA página** se construye este ciclo; promise/mechanism/offer matchean la Cold-Friendly Offer; primer heatmap review agendado 5–7 días post-launch.

---

## 4) La regla de congruencia (constraint duro — M14)

**Construir desde el ÁNGULO ganador, no desde el producto.** Y a lo largo de todo el funnel, **promise / mechanism / offer deben ser IDÉNTICOS** de creativo → presell → offer page. Esto es *The Handover* (M14.1): se escribe ANTES de abrir el page builder y es el mismo texto en el presell Y en el destino:

```
THE HANDOVER
Promise   : [la promesa exacta del ángulo ganador]
Mechanism : [el cómo — el mecanismo diferencial, verbatim]
Offer     : [precio · bundle · garantía]
```

Cualquier ruptura de este trío entre saltos = **fuga de congruencia**, la causa nº1 de tráfico perdido. Un ad que promete un mecanismo y aterriza en un PDP genérico que vende "el producto" rompe la congruencia dos veces (falta presell + promesa distinta).

Base de research antes de escribir cualquier página: **PMBD = Pains / Motives / Beliefs / Desires** (de surveys, customer service, reviews, DMs, comments). Se construye desde el research + el ángulo, no desde el catálogo.

---

## 5) Biblioteca de palancas AOV / CLV (🟢) — dónde viven en el funnel

| Step | Palancas | Nota |
|---|---|---|
| **Offer page** | Bundle (anchor de precio), **pre-select** del pack ganador, **decoy** (3/5/7 packs con el 5 pre-seleccionado + bestseller badge), old price tachado + "save €X" | Female Company: A/B LP-con-oferta vs collection = **+26% CVR, hasta −34% CPA**. |
| **Checkout** | **Cross-sells** / frequently-bought-together, nudging para quitar ansiedad | Es un step con derecho propio, no "parte de Shopify". |
| **Post-purchase** | **Upsells one-time** (NuBrew: 3 upsells post-compra), subscription, **comunidad** | PetLab: comunidad de **123k** en Facebook = motor de CLV. |
| **Email (🟤)** | Secuencias que empujan entre steps; email #2 con **vídeo personalizado** (Java: "Natalie") | Subir del presell a la oferta y de la 1ª compra a la recompra. |

Su ausencia se diagnostica: "offer page sin bundle/decoy", "checkout sin cross-sell", "cero post-purchase", "no hay comunidad".

---

## 6) Casos de referencia (estructuras de funnel — literales del curso)

- **Vessi** (waterproof shoes): abre mercado **unaware** con narrativa "travel"; UGC de un travel-photographer → **LP congruente idéntica** al creativo. Lección: congruencia creativo→LP verbatim + abrir unaware por TAM.
- **Cocunat** ("curly method"): 6–7 avatares distintos → **LP bundle** (~€70), 8 secciones (countdown → hero mirror-neuron → oferta bundle con old price tachado + 3.000 5★ → benefits-not-features → social proof/before-after "1M women" → pain agitation → **mechanism/how-it-works** [obligatorio por soph alta en beauty] → repeat benefits para skimmers). Lección: **repetir el mismo beneficio en varios diseños para skimmers; beneficios sobre features**.
- **Kinobody** (30-Day Mojo Mastery Challenge): AOV $40 → $97 + $69/mo; **NCPA −66%, spend −41%, 9,3× ROAS**. 5-step: angle-test (gana "dating") → double-down → iterate → VSL → LP (8 secciones). Lección: el funnel escala cuando el ángulo ganado se lleva verbatim a VSL + LP. (Números = proof assets para pitches.)
- **PetLab** (advertorial de vet): producto revelado al ~75% del advertorial → preselect **subscription + cross-sells** → one-time upsell → **comunidad de 123k en Facebook**. Lección: presell advertorial largo + capas AOV/CLV + comunidad como CLV.
- **NuBrew** (advertorial estilo NYT): advertorial editorial → 6-month supply £129 → **3 upsells post-purchase**. Lección: post-purchase con múltiples upsells one-time.
- **Java Coffee**: listicle "10 reasons" → preselect 4-bottle + gift → **email #2 con vídeo personalizado ("Natalie")**. Lección: listicle como presell + email (🟤) empujando entre steps.

---

## 7) Ejemplo trabajado end-to-end (marca sintética "KneeFlow", rodilleras DTC)

**Input:** el ad (soph 4, Solution-Aware) manda directo a `/products/knee-sleeve`. No hay presell. Offer page = PDP genérico sin bundle. No hay retargeting ni post-purchase.

**1) FUNNEL MAP**
```
FUNNEL MAP — KneeFlow · 28-sep · Tráfico de entrada: Solution-Aware × soph 4
Step                     | Live URL                     | What it does to the visitor              | Owning block               | Traffic lost here (source)
Prospecting ad (TOF)     | Meta camp. "Knee pain 50+"   | FOMO + promesa "camina sin dolor"        | mlo-sistema-creativo-2026  | sin dato (falta hook-rate)
Presell (listicle/adv.)  | does not exist               | —(no convierte curiosidad en razón)      | listicle-adv-brief+cooker  | fuga estructural: ad→PDP directo
  ├ click → offer        | (rama)                       | —                                        | —                          | —
  └ no click → retarget  | does not exist               | —(objeción no muere; tráfico se enfría)  | mlo-sistema-creativo-2026  | 100% del no-click perdido
Offer page               | /products/knee-sleeve (PDP)  | Vende producto pero sin trust ni AOV     | mlo-page-cooker+cro-2026   | 91% bounce · GA4 landing · 20-sep
Checkout                 | Shopify checkout             | Sin cross-sells                          | mlo-cro-2026               | sin dato
Post-purchase            | does not exist               | —(cero upsell, cero comunidad)           | cro-2026 / creator-coord   | CLV plano (sin recompra)
```

**2) DIAGNÓSTICO — steps faltantes / rotos (priorizado)**
1. **Falta presell (crítico).** El ad va directo al PDP → rompe la espina y la congruencia. Cambio de mente ausente: "curiosidad del ad → razón para leer la oferta". Owning: `mlo-listicle-advertorial-brief` + `mlo-page-cooker`. Fuga: 91% bounce en el PDP-como-landing.
2. **Offer page es un PDP genérico sin trust ni AOV.** Soph 4 exige mecanismo + prueba; falta bundle/decoy/pre-select. Owning: `mlo-page-cooker` + `mlo-cro-2026`.
3. **No hay retargeting testimonial.** Todo el no-click se enfría. Owning: `mlo-sistema-creativo-2026`.
4. **Cero post-purchase / comunidad.** CLV plano. Owning: `mlo-cro-2026` / `mlo-creator-coordinator` (comunidad).
5. **Checkout sin cross-sell** (`unowned` hasta agendarlo).

**3) BUILD ORDER**
```
THE HANDOVER (idéntico en presell y offer page)
Promise   : "vuelve a caminar sin dolor de rodilla, sin pastillas"
Mechanism : "compresión graduada 4D que reactiva la circulación"
Offer     : pack de 2 · €59 (antes €98) · 60 noches o te devolvemos

1. PRESELL — advertorial (soph 4 + Solution-Aware = pista media, editorial con mecanismo)
   → mlo-listicle-advertorial-brief (brief) → mlo-page-cooker (build)
2. OFFER PAGE — LP congruente con bundle pre-select + decoy 1/2/4 + trust/mechanism
   → mlo-page-cooker + mlo-cro-2026
3. RETARGETING testimonial para el no-click
   → mlo-sistema-creativo-2026
4. POST-PURCHASE — 1 upsell one-time + arranque de comunidad
   → mlo-cro-2026 / mlo-creator-coordinator

→ pasar el block #1 (brief del advertorial) a mlo-page-cooker.
```

**DoD:** mapa pegado en Slack; cada step con block o `unowned`; el cliente confirma por escrito que se construye primero el advertorial; heatmap review agendado 5–7 días post-launch.
