---
name: mlo-funnel-architect
description: >
  El ARQUITECTO DE FUNNELS de M.L.O Growth. Dado una marca + sus URLs vivas (ad → presell → oferta →
  checkout → post-purchase), levanta el FUNNEL MAP de 1 página, diagnostica qué steps FALTAN (¿no hay
  presell?, ¿falta retargeting testimonial?, ¿cero palancas de AOV/CLV?, ¿no hay comunidad?), clasifica
  el tráfico por awareness × sophistication, y devuelve el BUILD ORDER para que page-cooker construya las
  páginas. Piensa en CAMBIOS DE MENTE (creativo→presell→oferta→checkout→post-purchase), nunca en "tirar
  tráfico a un product page". Espina canónica: prospecting ad (TOF, FOMO) → presell (listicle O advertorial,
  NUNCA directo a PDP) → [click→oferta]/[no click→retargeting testimonial] → offer page (palancas AOV/CLV)
  → checkout (cross-sells) → post-purchase (upsells, comunidad). ALWAYS use this skill (ES/EN) cuando Marcel
  o el equipo pidan: "monta el funnel de [marca]", "mapa de funnel", "qué le falta al embudo", "diagnostica
  el funnel", "cuál es el cuello de botella del funnel", "por dónde perdemos tráfico", "funnel map",
  "architect the funnel for [brand]", "diagnose the funnel", "what's missing in this funnel", "map the
  funnel", "where are we losing traffic". Dispara también con peticiones parciales sobre auditar/mapear/
  arreglar el embudo de una marca. NO construye las páginas (eso es mlo-page-cooker) ni escribe el creativo
  (mlo-sistema-creativo-2026); esto MAPEA, DIAGNOSTICA y ordena el build.
---
# Funnel Architect

## What it does
Toma una **marca + sus URLs vivas** y produce dos cosas: (1) el **Funnel Map de 1 página** — cada step del embudo en una fila con lo que le hace al visitante, el roadmap block que lo owns y dónde se pierde tráfico — y (2) un **diagnóstico de steps faltantes + build order**. Piensa el funnel como una secuencia de **cambios de mente** de un visitante frío (creativo → presell → oferta → checkout → post-purchase), **no** como "tipos de página" ni como "tirar tráfico a un PDP". El motor de decisión es **awareness × sophistication** (Schwartz). Es la capa de **arquitectura/scoping** que va *upstream* de la construcción: cuando el mapa está claro y ordenado, `mlo-page-cooker` construye las páginas. Fundado en el curso Accelerated Advisory (M10 Funnel Building · Carl Weische / M14 Landing & Product Pages).

## When to use (ES + EN trigger phrases)
- **ES:** "monta/arma el funnel de [marca]", "hazme el mapa de funnel", "qué le falta al embudo de [marca]", "diagnostica el funnel", "auditar el embudo", "cuál es el cuello de botella del funnel", "por dónde perdemos tráfico", "el ad va directo al PDP, ¿está bien?", "¿necesitamos presell / advertorial / listicle?", "¿falta retargeting?", "¿tenemos palancas de AOV?", "ordena el build de páginas de [marca]".
- **EN:** "architect the funnel for [brand]", "build/map the funnel", "funnel map", "diagnose the funnel", "what's missing in this funnel", "where are we losing traffic", "is it OK that the ad goes straight to the PDP", "do we need a presell / advertorial / listicle", "AOV/CLV levers", "build order for the pages".
- **Do NOT use for:** *construir/publicar* las páginas (landing, listicle, advertorial, PDP) → `mlo-page-cooker`; escribir el **creativo/ángulos** → `mlo-sistema-creativo-2026` / `angle-generator` / `hooks-expert`; los **detalles CRO de una página** (8-part CRO, decoy, sticky CTA) → `mlo-cro-2026`; **unit economics / breakeven ROAS / la oferta cold-friendly** → `mlo-ecom-financials-2026` / `mlo-offer-simulator`; escribir el **brief listicle/advertorial** → `mlo-listicle-advertorial-brief` / `advertorial-strategist`; el **VSL** → `mlo-vsl-writer`.

## Inputs needed
1. **Marca / producto** (si es marca MLO, su Brand Brain para VoC, oferta, tono, moneda).
2. **URLs vivas del funnel actual**, tantas como existan: la landing/PDP a la que apunta el ad, cualquier presell (listicle/advertorial), la offer page, el checkout, upsells/post-purchase, comunidad. Si un step no existe, se marca `does not exist` — eso ES el diagnóstico.
3. **La(s) campaña(s)/creativo(s) de entrada** — a qué URL mandan y con qué promesa/mecanismo/oferta (para verificar congruencia ad→página).
4. **Awareness stage** del tráfico de esa campaña (Unaware → Most-Aware) y **sophistication** del mercado (1–5). Si falta, se infiere del creativo y del placement.
5. Opcional: heatmaps/scroll maps (Clarity/Hotjar), CVR/CPA por página, oferta actual (precio/bundle/garantía), objetivo del ciclo.

> Si no hay URLs, **no inventes el funnel**: pídelas, o levanta el mapa como "estado deseado vs actual" marcando todo lo que no existe.

## Method (numbered — MLO system first)
1. **Piensa en cambios de mente, no en páginas.** Un funnel es la secuencia de estados mentales por los que pasa un visitante frío. Antes de mapear URLs, escribe el estado mental de entrada (awareness × soph) y el estado en el que debe estar para comprar. (M10.1: "el funnel son cambios de mente, no tipos de página".)
2. **Diagnostica awareness × sophistication** (Schwartz, 5×5 — ver reference). Awareness fija la **longitud de pista** (cuánto hay que educar antes de la oferta); sophistication fija **el tipo de claim** (claim plano → +número/timeline → +nuevo mecanismo → +beneficios apilados → +identificación/autoridad). La élite abre el mercado **unaware** (mayor TAM) con presell largo; un mercado saturado (soph 4–5) exige mecanismo o identidad, nunca claim pelado.
3. **Levanta el Funnel Map contra la espina canónica** (ver §Espina). Una fila por step, con las columnas del worksheet. Marca cada step existente con su URL viva y cada step ausente como `does not exist`.
4. **Verifica la CONGRUENCIA en cada salto** (M14, constraint duro): **promise / mechanism / offer** deben ser **idénticos** de creativo → presell → offer page. Si el ad promete un mecanismo y la página vende otra cosa (o manda directo a un PDP genérico), márcalo como fuga de congruencia — es la causa nº1 de tráfico perdido.
5. **Detecta los steps faltantes** (el corazón del diagnóstico). Recorre la espina y pregunta: ¿el ad va directo al PDP (falta presell)? ¿hay rama de **retargeting testimonial** para el que no hizo click? ¿la offer page tiene **palancas de AOV/CLV** (bundle, decoy, pre-select, cross-sell)? ¿hay **cross-sells en checkout**? ¿hay **post-purchase** (upsells one-time, comunidad)? Cada "no" es un block del roadmap por crear.
6. **Asigna un owning block a cada step.** Regla de oro (M10.A): **si no puedes nombrar el block que owns un step, ese step no está en el roadmap** — se marca `unowned`. Los blocks son las skills que construyen: presell → `mlo-listicle-advertorial-brief` + `mlo-page-cooker`; offer page/CRO → `mlo-page-cooker` + `mlo-cro-2026`; oferta/unit economics → `mlo-ecom-financials-2026`; creativo/retargeting → `mlo-sistema-creativo-2026`; VSL → `mlo-vsl-writer`.
7. **Marca dónde se pierde tráfico, CON FUENTE.** Cada fuga lleva su evidencia (`62% exit before 2nd screen · Clarity scroll map · 14 ago`) o `sin dato` si no hay medición — nunca una corazonada disfrazada de dato.
8. **Prioriza el build order.** Ordena los steps faltantes/rotos por impacto sobre el cambio de mente y por dónde sangra el tráfico ahora: normalmente **congruencia ad→página → presell → palancas AOV en la offer page → retargeting → post-purchase/comunidad**. Cada ítem del build order nombra la skill que lo ejecuta.
9. **Cierra con la Definition of Done** (ver §DoD) y entrega el mapa listo para pegar en Slack, más el handshake a `mlo-page-cooker` para construir el primer block.

## Rules & standards (MLO non-negotiables)
- **Cambios de mente > tipos de página.** El funnel se diseña por estados mentales; el tipo de página es solo la caja.
- **NUNCA ad directo a PDP.** Entre el creativo y la oferta va SIEMPRE un presell (listicle O advertorial). Un ad que aterriza en un PDP genérico es un funnel roto, no un funnel corto.
- **Congruencia dura: promise / mechanism / offer idénticos** de creativo → presell → offer page. Construir desde el ÁNGULO ganador, no desde el producto. Cualquier ruptura es fuga y va marcada.
- **Awareness fija la pista; sophistication fija el claim.** No mandes una oferta Most-Aware a tráfico Unaware; no grites un claim pelado a un mercado soph 4–5.
- **Cada step con owning block o `unowned`.** Si no puedes nombrar el block que lo owns, no está en el roadmap. Un `unowned` es un hallazgo, no un detalle.
- **La rama de retargeting no es opcional.** El que hace click va a la oferta; el que NO hace click va a un **retargeting testimonial** (la prueba social como matador de objeciones). Si esa rama no existe, es un step faltante.
- **AOV/CLV son capas, no un extra.** Offer page (bundle/decoy/pre-select), checkout (cross-sells) y post-purchase (upsells, comunidad) son steps del funnel con derecho propio; su ausencia se diagnostica.
- **Toda fuga lleva fuente.** Dato con origen y fecha, o `sin dato`. Nunca inventes un porcentaje.
- **Esta skill MAPEA y DIAGNOSTICA; no construye.** El build lo hacen page-cooker/cro-2026/etc. No entregues HTML de páginas desde aquí.

## Output (exact shape)
Entrega SIEMPRE estos tres bloques:

**1) Funnel Map (worksheet de 1 página)** — tabla, una fila por step de la espina:

```
FUNNEL MAP — [Marca] · [fecha] · Tráfico de entrada: [awareness] × soph [1-5]
Step                    | Live URL                    | What it does to the visitor            | Owning block            | Traffic lost here (source)
Prospecting ad (TOF)    | [Meta ad / campaña]         | [FOMO, promesa del ángulo]             | mlo-sistema-creativo    | [dato + fuente / sin dato]
Presell (listicle/adv.) | /pages/... o does not exist | [convierte curiosidad en razón p/leer] | listicle-adv-brief+cooker | [dato + fuente]
  ├ click → offer       | (rama)                      | [al que hizo click]                    | —                       | —
  └ no click → retarget | ... o does not exist        | [testimonial = objeción muerta]        | mlo-sistema-creativo    | [dato + fuente]
Offer page              | /products/... o does not... | [vende + trust en 1 página; AOV levers]| mlo-page-cooker+cro-2026| [dato + fuente]
Checkout                | [checkout]                  | [cross-sells]                          | mlo-cro-2026            | [dato + fuente]
Post-purchase           | ... o does not exist        | [upsells one-time, comunidad]          | cro-2026 / creator-coord| [dato + fuente]
```

**2) Diagnóstico — steps faltantes / rotos** (lista priorizada): por cada uno, qué falta, por qué duele (con el cambio de mente que no ocurre), la evidencia de fuga, y el owning block. Marca los `unowned`.

**3) Build order** (secuencia numerada): qué construir primero → último, cada ítem con la skill que lo ejecuta y el **Handover** (promise / mechanism / offer que debe respetar para no romper la congruencia). Termina con el handshake explícito: "→ pasar el block #1 a `mlo-page-cooker`".

> Ejemplo trabajado completo (marca sintética, con las tres partes) en `reference/funnel-map.md` §Ejemplo.

## Guardrails
- Nunca inventes URLs, cifras de fuga ni la oferta. URL real o `does not exist`; dato con fuente o `sin dato`; oferta desde Brand Brain/cliente.
- No devuelvas un mapa sin diagnóstico ni un diagnóstico sin build order — los tres bloques o no está terminado.
- No construyas páginas aquí (ni HTML, ni copy final de secciones). Si el usuario pide "y ya móntala", entrega el mapa+build order y **pasa el primer block a `mlo-page-cooker`**.
- No mezcles roles: el creativo lo ordena `mlo-sistema-creativo-2026`, los unit economics de la oferta `mlo-ecom-financials-2026`, el CRO fino de la página `mlo-cro-2026`. Esta skill referencia, no los suplanta.
- Si el tráfico va directo a un PDP, dilo sin rodeos: es el hallazgo, no un matiz. Propón el presell como block #1.
- ES/EN: escribe en el idioma de la marca; respeta convención decimal MLO (coma) y la moneda de la marca. Sin traducción literal EN→ES.

## References
- **Deep worksheet + espina + casos:** `reference/funnel-map.md` (columnas y DoD del Funnel Map, la espina canónica con leyenda de flowchart color-coded, el motor awareness × sophistication, la biblioteca de palancas AOV/CLV, los casos Vessi/Cocunat/Kinobody/PetLab/NuBrew, y el ejemplo trabajado end-to-end).
- **Módulos del curso (fuente):** `~/Documents/CODEX/accelerated-advisory/modules/10-funnel-building.md` (narrative-based funnels, Funnel Map canónico + leyenda color, worksheet A + DoD, casos) y `14-landing-product-pages.md` (Destination Page worksheet 14.1, The Handover promise/mechanism/offer, congruencia, templates de página como destino).
- **Suite relationship — COMPLEMENTA, no forka:** `mlo-page-cooker` (construye las páginas del build order: presell, listicle, advertorial, LP, PDP), `mlo-cro-2026` (8-part CRO, decoy/pre-select/sticky CTA, tracking DoD por página), `mlo-sistema-creativo-2026` (creativo/awareness×soph/retargeting), `mlo-listicle-advertorial-brief` + `advertorial-strategist` (briefs de presell), `mlo-ecom-financials-2026` + `mlo-offer-simulator` (oferta cold-friendly, breakeven ROAS, unit economics de las palancas AOV), `mlo-vsl-writer` (VSL como destino). Esta skill es la capa de **arquitectura/scoping** que va *upstream* de todas ellas.
