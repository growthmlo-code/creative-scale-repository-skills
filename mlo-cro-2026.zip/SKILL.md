---
name: mlo-cro-2026
description: El cerebro de CRO (optimización de conversión) y funnels de respuesta directa de M.L.O Growth para eCommerce DTC en 2026. Contiene el sistema completo — por qué el conversion rate MIENTE y hay que medir RPV/contribución por visitante, las 5 palancas en orden (claridad/jerarquía, copy, oferta, prueba, fricción), las 4 preguntas del above the fold, la continuidad ad→landing (message match, el hack más grande), el copywriting benefit-led (so-what test, uno-de-uno, océano azul, objection handling, FAQ), la oferta como POSICIONAMIENTO no descuento (bundles, gift with purchase, shipping, post-purchase upsell, cart slide-out), la prueba que coincide con el claim (reviews, foto/vídeo primero, trust signals), el checkout sin fricción (las razones reales de abandono y cómo eliminarlas), el mito del A/B testing (RPV, volumen de sesiones, contaminación, cuándo sí), PDP vs landing vs advertorial, y TODO el sistema de FUNNELS DE RESPUESTA DIRECTA — por qué mandar ads a la PDP te atasca, el funnel unaware/problem-aware (ad → presell → offer page → checkout), la congruencia total por ángulo/avatar, la anatomía de 10 secciones del ADVERTORIAL (hook, dolor emocional, por qué nada funcionó, causa raíz, mecanismo único, proof story, objeciones, precio+escasez, garantía, comentarios), el QUIZ FUNNEL (plantilla 18 slides), las presell pages (advertorial vs listicle), el pain threshold, vender=crear separación, future pacing y el escalado horizontal. ALWAYS use this skill (ES/EN) cuando Marcel o el equipo pidan: "optimiza esta landing/PDP", "por qué no convierte", "sube la conversión de [marca]", "cómo mido conversión / RPV", "revisa el checkout", "hazme un advertorial / presell page / listicle", "monta un quiz funnel", "cómo estructuro el funnel de respuesta directa", "cómo escalo cold traffic / unaware", "qué oferta pongo en la landing", "reviso el above the fold", "message match", "A/B testing sí o no", "CRO 2026", o cuando haya que redactar formación, SOPs o lead magnets de CRO / conversión / landing pages / funnels. Dispara también con peticiones parciales o coloquiales sobre landing pages, PDPs, checkout, ofertas on-page, advertoriales, quiz funnels, presell pages o por qué una cuenta se atasca en un techo de gasto.
---

# Sistema de CRO y Funnels de Respuesta Directa M.L.O 2026

Este skill es el **cerebro de conversión** de M.L.O Growth: cómo optimizar landings/PDPs de verdad (no cambiar el color del botón) y cómo construir **funnels de respuesta directa** (advertoriales, quiz funnels, presell pages) para escalar tráfico frío/unaware. Es donde el creativo, el media buying y el CRO se juntan. Lo usamos para:

- **Auditar y optimizar** una PDP/landing (medir RPV, priorizar por ICE, arreglar las 5 palancas).
- **Escribir advertoriales, presell pages, listicles y quiz funnels** para clientes.
- **Diagnosticar** por qué una cuenta se atasca en un techo de gasto (casi siempre falta la capa de presell).
- **Formar al equipo** y **generar lead magnets/SOPs** de CRO y funnels (Módulo 05 del lead bucket).

## Cómo usarlo

1. **Lee el cerebro completo** en `references/cro-brain.txt`. Es la fuente única de verdad: Parte A (CRO on-page, bloques 1–9) y Parte B (funnels de respuesta directa, bloques 10–13), con reglas, fórmulas y estructuras.
2. **Cruza con el resto del sistema M.L.O**: el sistema creativo (persona × ángulo × oferta, awareness, hooks, VSL) en `[[mlo-sistema-creativo-2026]]`; la estructura de cuenta y escalado en `[[mlo-media-buying-2026]]`; los 12 frameworks de guion del Playbook de Scripting; definiciones de winner/KPIs en `[[mlo-estratega-creativo]]`. Un funnel de respuesta directa necesita los tres.
3. **Adapta a la voz M.L.O**: frases cortas, sin anglicismos innecesarios, práctico, sin humo. Para cliente/lead magnet cierra con el CTA de auditoría gratuita (mlo-growth.com/adquisicion/metodolgia-mlo-growth-3).

## Reglas de oro

- **Mide el número correcto.** El conversion rate es un output de ~50 variables y es "gameable". Mide **RPV** (revenue per visitor) o contribución por visitante. La conversión es un diagnóstico, no un norte.
- **Las 5 palancas, en orden**: claridad/jerarquía → copy → oferta → prueba → fricción. Prioriza por ICE. Mobile first.
- **Continuidad ad→landing** = el hack más grande. Un concepto = persona, oferta o ángulo; refléjalo en la landing.
- **Oferta = posicionamiento, no descuento.** Protege (y sube) el margen con bundles, GWP, umbrales y upsells.
- **No prometas lo que el producto no cumple** (protege el LTV).
- **El funnel se construye en secuencia; nada se salta.** Ad → presell → offer page → checkout, todo congruente al mismo ángulo/avatar. Retargeting devuelve a la presell.

## Origen

Destilado e internalizado a estándar M.L.O a partir de material de mercado sobre CRO, advertoriales, quiz funnels y funnels de respuesta directa en eCommerce 2026. Reescrito por completo con nuestra terminología y ejemplos genéricos (sin marcas/agencias ajenas). Se mejora con el tiempo (versionado en el propio cerebro).
